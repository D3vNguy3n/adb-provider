package com.dnturbo.adb;

import android.content.Context;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.util.Log;

import java.io.Closeable;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.SocketException;
import java.util.Enumeration;
import java.util.List;

public class AdbMdns implements Closeable {

    public static final String TLS_CONNECT = "_adb-tls-connect._tcp";
    public static final String TLS_PAIRING = "_adb-tls-pairing._tcp";
    public static final String TAG = "AdbMdns";

    private final String serviceType;
    private final AdbDiscoveryCallback observer;
    private final NsdManager nsdManager;
    private final WifiManager.MulticastLock multicastLock;
    private final DiscoveryListener listener = new DiscoveryListener();

    private boolean registered;
    private boolean running;
    private String serviceName;

    public AdbMdns(Context context, String serviceType, AdbDiscoveryCallback observer) {
        this.serviceType = serviceType;
        this.observer = observer;
        Context app = context.getApplicationContext();
        this.nsdManager = app.getSystemService(NsdManager.class);
        WifiManager wifi = (WifiManager) app.getSystemService(Context.WIFI_SERVICE);
        if (wifi != null) {
            multicastLock = wifi.createMulticastLock("adb-mdns");
            multicastLock.setReferenceCounted(false);
        } else {
            multicastLock = null;
        }
    }

    public void start() {
        if (running) {
            return;
        }
        running = true;
        if (multicastLock != null) {
            multicastLock.acquire();
        }
        if (!registered) {
            nsdManager.discoverServices(serviceType, NsdManager.PROTOCOL_DNS_SD, listener);
        }
    }

    public void stop() {
        if (!running) {
            return;
        }
        running = false;
        if (registered) {
            nsdManager.stopServiceDiscovery(listener);
        }
        if (multicastLock != null && multicastLock.isHeld()) {
            multicastLock.release();
        }
    }

    @Override
    public void close() {
        stop();
    }

    private void onDiscoveryStart() {
        registered = true;
    }

    private void onDiscoveryStop() {
        registered = false;
    }

    private void onServiceFound(NsdServiceInfo info) {
        nsdManager.resolveService(info, new ResolveListener());
    }

    private void onServiceLost(NsdServiceInfo info) {
        if (info.getServiceName() != null && info.getServiceName().equals(serviceName)) {
            observer.onServiceChanged(new AdbService("", -1));
        }
    }

    private void onServiceResolved(NsdServiceInfo resolvedService) {
        String host = hostAddress(resolvedService);
        if (host == null) {
            return;
        }
        if (running && isLocalAddress(host) && isPortAvailable(host, resolvedService.getPort())) {
            serviceName = resolvedService.getServiceName();
            observer.onServiceChanged(new AdbService(host, resolvedService.getPort()));
        }
    }

    private String hostAddress(NsdServiceInfo info) {
        if (Build.VERSION.SDK_INT >= 34) {
            List<InetAddress> addresses = info.getHostAddresses();
            if (addresses != null && !addresses.isEmpty()) {
                return addresses.get(0).getHostAddress();
            }
            return null;
        }
        InetAddress host = info.getHost();
        return host != null ? host.getHostAddress() : null;
    }

    private boolean isLocalAddress(String host) {
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            if (interfaces == null) {
                return false;
            }
            while (interfaces.hasMoreElements()) {
                NetworkInterface nif = interfaces.nextElement();
                Enumeration<InetAddress> addresses = nif.getInetAddresses();
                while (addresses.hasMoreElements()) {
                    if (host.equals(addresses.nextElement().getHostAddress())) {
                        return true;
                    }
                }
            }
        } catch (SocketException ignored) {
        }
        return false;
    }

    private boolean isPortAvailable(String host, int port) {
        try (ServerSocket socket = new ServerSocket()) {
            socket.bind(new InetSocketAddress(host, port), 1);
            return false;
        } catch (IOException e) {
            return true;
        }
    }

    private class DiscoveryListener implements NsdManager.DiscoveryListener {
        @Override
        public void onDiscoveryStarted(String serviceType) {
            Log.v(TAG, "onDiscoveryStarted: " + serviceType);
            onDiscoveryStart();
        }

        @Override
        public void onStartDiscoveryFailed(String serviceType, int errorCode) {
            Log.w(TAG, "onStartDiscoveryFailed: " + serviceType + ", " + errorCode);
        }

        @Override
        public void onDiscoveryStopped(String serviceType) {
            Log.v(TAG, "onDiscoveryStopped: " + serviceType);
            onDiscoveryStop();
        }

        @Override
        public void onStopDiscoveryFailed(String serviceType, int errorCode) {
            Log.w(TAG, "onStopDiscoveryFailed: " + serviceType + ", " + errorCode);
        }

        @Override
        public void onServiceFound(NsdServiceInfo serviceInfo) {
            Log.v(TAG, "onServiceFound: " + serviceInfo.getServiceName());
            AdbMdns.this.onServiceFound(serviceInfo);
        }

        @Override
        public void onServiceLost(NsdServiceInfo serviceInfo) {
            Log.v(TAG, "onServiceLost: " + serviceInfo.getServiceName());
            AdbMdns.this.onServiceLost(serviceInfo);
        }
    }

    private class ResolveListener implements NsdManager.ResolveListener {
        @Override
        public void onResolveFailed(NsdServiceInfo nsdServiceInfo, int i) {
        }

        @Override
        public void onServiceResolved(NsdServiceInfo nsdServiceInfo) {
            AdbMdns.this.onServiceResolved(nsdServiceInfo);
        }
    }
}
