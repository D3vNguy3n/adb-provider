package com.dnturbo.adb;

import android.os.Build;
import android.util.Log;

import java.io.Closeable;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.function.Consumer;

import javax.net.ssl.SSLSocket;

public class AdbClient implements Closeable {

    private static final String TAG = "AdbClient";

    private final String host;
    private final int port;
    private final AdbKey key;
    private final int connectTimeoutMs;

    private Socket socket;
    private DataInputStream plainInputStream;
    private DataOutputStream plainOutputStream;
    private boolean useTls;
    private SSLSocket tlsSocket;
    private DataInputStream tlsInputStream;
    private DataOutputStream tlsOutputStream;

    public AdbClient(String host, int port, AdbKey key) {
        this(host, port, key, 5000);
    }

    public AdbClient(String host, int port, AdbKey key, int connectTimeoutMs) {
        this.host = host;
        this.port = port;
        this.key = key;
        this.connectTimeoutMs = connectTimeoutMs;
    }

    private DataInputStream inputStream() {
        return useTls ? tlsInputStream : plainInputStream;
    }

    private DataOutputStream outputStream() {
        return useTls ? tlsOutputStream : plainOutputStream;
    }

    public void connect() throws Exception {
        AdbNative.ensureLoaded();
        socket = new Socket();
        socket.connect(new InetSocketAddress(host, port), connectTimeoutMs);
        socket.setTcpNoDelay(true);
        // Also bound the ADB authentication handshake. Without a read timeout an
        // unanswered/denied RSA confirmation dialog can block this thread forever.
        socket.setSoTimeout(connectTimeoutMs);
        plainInputStream = new DataInputStream(socket.getInputStream());
        plainOutputStream = new DataOutputStream(socket.getOutputStream());

        write(AdbProtocol.A_CNXN, AdbProtocol.A_VERSION, AdbProtocol.A_MAXDATA, "host::");

        AdbMessage message = read();
        if (message.command == AdbProtocol.A_STLS) {
            if (Build.VERSION.SDK_INT < 29) {
                throw new IllegalStateException("Connect to adb with TLS is not supported before Android 9");
            }
            write(AdbProtocol.A_STLS, AdbProtocol.A_STLS_VERSION, 0, (byte[]) null);

            tlsSocket = (SSLSocket) key.getSslContext().getSocketFactory()
                    .createSocket(socket, host, port, true);
            tlsSocket.setSoTimeout(connectTimeoutMs);
            tlsSocket.startHandshake();
            Log.d(TAG, "Handshake succeeded.");

            tlsInputStream = new DataInputStream(tlsSocket.getInputStream());
            tlsOutputStream = new DataOutputStream(tlsSocket.getOutputStream());
            useTls = true;

            message = read();
        } else if (message.command == AdbProtocol.A_AUTH) {
            write(AdbProtocol.A_AUTH, AdbProtocol.ADB_AUTH_SIGNATURE, 0, key.sign(message.data));
            message = read();
            if (message.command != AdbProtocol.A_CNXN) {
                write(AdbProtocol.A_AUTH, AdbProtocol.ADB_AUTH_RSAPUBLICKEY, 0, key.getAdbPublicKey());
                message = read();
            }
        }

        if (message.command != AdbProtocol.A_CNXN) {
            throw new IllegalStateException("not A_CNXN");
        }

        // Commands may legitimately take longer than the authentication timeout.
        socket.setSoTimeout(0);
        if (tlsSocket != null) {
            tlsSocket.setSoTimeout(0);
        }
    }

    public void command(String cmd, Consumer<byte[]> listener) throws Exception {
        int localId = 1;
        write(AdbProtocol.A_OPEN, localId, 0, cmd);

        AdbMessage message = read();
        if (message.command == AdbProtocol.A_OKAY) {
            while (true) {
                message = read();
                int remoteId = message.arg0;
                if (message.command == AdbProtocol.A_WRTE) {
                    if (message.dataLength > 0 && listener != null) {
                        listener.accept(message.data);
                    }
                    write(AdbProtocol.A_OKAY, localId, remoteId, (byte[]) null);
                } else if (message.command == AdbProtocol.A_CLSE) {
                    write(AdbProtocol.A_CLSE, localId, remoteId, (byte[]) null);
                    break;
                } else {
                    throw new IllegalStateException("not A_WRTE or A_CLSE");
                }
            }
        } else if (message.command == AdbProtocol.A_CLSE) {
            write(AdbProtocol.A_CLSE, localId, message.arg0, (byte[]) null);
        } else {
            throw new IllegalStateException("not A_OKAY or A_CLSE");
        }
    }

    public String shell(String cmd) throws Exception {
        StringBuilder out = new StringBuilder();
        command("shell:" + normalizeShellCommand(cmd), bytes ->
                out.append(new String(bytes, StandardCharsets.UTF_8)));
        return out.toString();
    }

    /** {@code ls} / {@code shell ls} / {@code adb shell ls} → {@code ls}. */
    public static String normalizeShellCommand(String cmd) {
        if (cmd == null) {
            return "";
        }
        String s = cmd.trim();
        if (s.regionMatches(true, 0, "adb shell ", 0, 10)) {
            s = s.substring(10).trim();
        } else if (s.regionMatches(true, 0, "shell:", 0, 6)) {
            s = s.substring(6).trim();
        } else if (s.regionMatches(true, 0, "shell ", 0, 6)) {
            s = s.substring(6).trim();
        }
        return s;
    }

    /**
     * Ask adbd to listen on a TCP port ({@code adb tcpip <port>}).
     * The connection is expected to drop when the daemon restarts.
     */
    public void tcpip(int port) throws Exception {
        try {
            command("tcpip:" + port, null);
        } catch (java.io.EOFException | java.net.SocketException ignored) {
        }
    }

    private void write(int command, int arg0, int arg1, byte[] data) throws Exception {
        write(new AdbMessage(command, arg0, arg1, data));
    }

    private void write(int command, int arg0, int arg1, String data) throws Exception {
        write(new AdbMessage(command, arg0, arg1, data));
    }

    private void write(AdbMessage message) throws Exception {
        outputStream().write(message.toByteArray());
        outputStream().flush();
        Log.d(TAG, "write " + message.toStringShort());
    }

    private AdbMessage read() throws Exception {
        ByteBuffer buffer = ByteBuffer.allocate(AdbMessage.HEADER_LENGTH).order(ByteOrder.LITTLE_ENDIAN);
        inputStream().readFully(buffer.array(), 0, 24);

        int command = buffer.getInt();
        int arg0 = buffer.getInt();
        int arg1 = buffer.getInt();
        int dataLength = buffer.getInt();
        int checksum = buffer.getInt();
        int magic = buffer.getInt();
        byte[] data = null;
        if (dataLength >= 0) {
            data = new byte[dataLength];
            inputStream().readFully(data, 0, dataLength);
        }
        AdbMessage message = new AdbMessage(command, arg0, arg1, dataLength, checksum, magic, data);
        message.validateOrThrow();
        Log.d(TAG, "read " + message.toStringShort());
        return message;
    }

    @Override
    public void close() {
        try {
            if (plainInputStream != null) {
                plainInputStream.close();
            }
        } catch (Throwable ignored) {
        }
        try {
            if (plainOutputStream != null) {
                plainOutputStream.close();
            }
        } catch (Throwable ignored) {
        }
        try {
            if (socket != null) {
                socket.close();
            }
        } catch (Exception ignored) {
        }
        if (useTls) {
            try {
                if (tlsInputStream != null) {
                    tlsInputStream.close();
                }
            } catch (Throwable ignored) {
            }
            try {
                if (tlsOutputStream != null) {
                    tlsOutputStream.close();
                }
            } catch (Throwable ignored) {
            }
            try {
                if (tlsSocket != null) {
                    tlsSocket.close();
                }
            } catch (Exception ignored) {
            }
        }
    }
}
