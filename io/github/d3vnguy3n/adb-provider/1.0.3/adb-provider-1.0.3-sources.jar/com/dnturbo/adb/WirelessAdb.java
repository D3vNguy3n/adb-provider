package com.dnturbo.adb;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import java.io.Closeable;
import java.net.SocketTimeoutException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;

/**
 * High-level API for Android 11+ wireless debugging: discover, pair, and connect.
 *
 * <p>Pairing and connecting use different mDNS services and different ports.
 * Pair once per device (or after "Forget pairing"), then {@link #connect(String, int)}
 * on the TLS connect port to run shell commands.
 */
public class WirelessAdb {

    public static final String PREFS_NAME = "adb_pairing";
    public static final String LOOPBACK = "127.0.0.1";
    public static final int DEFAULT_TCP_PORT = 5555;
    private static final String PREF_TCP_PORT = "tcp_port";
    private static final String PREF_TCP_READY = "tcp_ready";
    private static final String PREF_LAST_TLS_PORT = "last_tls_port";
    private static final String TAG = "WirelessAdb";

    private final Context appContext;
    private final AdbKeyStore keyStore;
    private final String keyName;
    private volatile AdbKey key;

    public WirelessAdb(Context context, AdbKeyStore keyStore, String keyName) {
        this.appContext = context.getApplicationContext();
        this.keyStore = keyStore;
        this.keyName = keyName;
    }

    public static WirelessAdb create(Context context) {
        return create(context, "DN-Turbo");
    }

    public static WirelessAdb create(Context context, String keyName) {
        return new WirelessAdb(
                context,
                new PreferenceAdbKeyStore(context.getApplicationContext()
                        .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)),
                keyName
        );
    }

    public AdbKey getKey() {
        AdbKey loaded = key;
        if (loaded == null) {
            synchronized (this) {
                loaded = key;
                if (loaded == null) {
                    try {
                        loaded = new AdbKey(keyStore, keyName);
                    } catch (Throwable t) {
                        throw new AdbKeyException(t);
                    }
                    key = loaded;
                }
            }
        }
        return loaded;
    }

    public Closeable discoverPairing(AdbDiscoveryCallback onFound) {
        AdbMdns mdns = new AdbMdns(appContext, AdbMdns.TLS_PAIRING, onFound);
        mdns.start();
        return mdns;
    }

    public Closeable discoverConnect(AdbDiscoveryCallback onFound) {
        AdbMdns mdns = new AdbMdns(appContext, AdbMdns.TLS_CONNECT, onFound);
        mdns.start();
        return mdns;
    }

    public void pair(String host, int port, String pairingCode) throws Exception {
        try (AdbPairingClient client = new AdbPairingClient(host, port, pairingCode.trim(), getKey())) {
            if (!client.start()) {
                throw new AdbException("Pairing failed");
            }
        }
    }

    public void pair(AdbService service, String pairingCode) throws Exception {
        pair(service.host, service.port, pairingCode);
    }

    public AdbClient connect(String host, int port) throws Exception {
        return connect(host, port, 5000);
    }

    public AdbClient connect(String host, int port, int timeoutMs) throws Exception {
        AdbClient client = new AdbClient(host, port, getKey(), timeoutMs);
        try {
            client.connect();
            return client;
        } catch (Exception e) {
            client.close();
            throw e;
        }
    }

    public AdbClient connect(AdbService service) throws Exception {
        return connect(service.host, service.port);
    }

    public int getTcpPort() {
        return prefs().getInt(PREF_TCP_PORT, DEFAULT_TCP_PORT);
    }

    /** Returns the TCP port currently advertised by adbd, or {@code -1} if unavailable. */
    public int getActiveTcpPort() {
        return systemTcpPort();
    }

    public boolean isTcpReady() {
        return prefs().getBoolean(PREF_TCP_READY, false) || systemTcpPort() > 0;
    }

    /**
     * Shizuku Start: always talk to {@code 127.0.0.1}.
     * If adbd already listens on TCP (wifi can be off), connect that port.
     * Otherwise discover the wireless TLS port, {@code tcpip:5555}, reconnect on 5555.
     */
    public AdbClient connectForUse(Consumer<String> log) throws Exception {
        return connectForUse(log, 20_000);
    }

    public AdbClient connectForUse(Consumer<String> log, long mdnsTimeoutMs) throws Exception {
        int tcpPort = getTcpPort();
        progress(log, "Starting with wireless adb...");

        int listening = systemTcpPort();
        if (listening > 0) {
            progress(log, "Connecting on port " + listening + "...");
            AdbClient client = connectWithRetry(LOOPBACK, listening, 5);
            markTcpReady(listening);
            progress(log, "Successfully connected on port " + listening + "...");
            return client;
        }

        AdbClient onTcp = tryConnect(LOOPBACK, tcpPort, 1500);
        if (onTcp != null) {
            markTcpReady(tcpPort);
            progress(log, "Successfully connected on port " + tcpPort + "...");
            return onTcp;
        }

        int lastTls = prefs().getInt(PREF_LAST_TLS_PORT, -1);
        if (lastTls > 0 && lastTls != tcpPort) {
            AdbClient onTls = tryConnect(LOOPBACK, lastTls, 1500);
            if (onTls != null) {
                return switchToTcp(onTls, lastTls, tcpPort, log);
            }
        }

        progress(log, "Searching for wireless debugging (mDNS)…");
        AdbService tls;
        try {
            tls = waitForConnectService(mdnsTimeoutMs);
        } catch (Exception e) {
            throw new AdbException(
                    AdbStrings.get(appContext, "adb_tcp_unavailable",
                            "TCP %1$d is unavailable. Enable Wireless debugging and tap Start "
                                    + "for the first connection (Wi-Fi is required now). You can "
                                    + "turn Wi-Fi off after TCP is ready.", tcpPort),
                    e
            );
        }
        prefs().edit().putInt(PREF_LAST_TLS_PORT, tls.port).apply();
        progress(log, "Connecting on port " + tls.port + "...");
        AdbClient tlsClient = connect(LOOPBACK, tls.port);
        progress(log, "Successfully connected on port " + tls.port + "...");
        return switchToTcp(tlsClient, tls.port, tcpPort, log);
    }

    /**
     * After pairing: switch to TCP before telling the user success,
     * so Wi‑Fi can be turned off immediately after.
     */
    public void enableTcpAfterPairing(Consumer<String> log) throws Exception {
        Thread.sleep(800);
        try (AdbClient ignored = connectForUse(log, 20_000)) {
            Log.i(TAG, "TCP mode enabled after pairing");
        }
    }

    public AdbService waitForConnectService(long timeoutMs) throws Exception {
        return waitForService(AdbMdns.TLS_CONNECT, timeoutMs);
    }

    public AdbService waitForPairingService(long timeoutMs) throws Exception {
        return waitForService(AdbMdns.TLS_PAIRING, timeoutMs);
    }

    private AdbService waitForService(String serviceType, long timeoutMs) throws Exception {
        AtomicReference<AdbService> found = new AtomicReference<>();
        CountDownLatch latch = new CountDownLatch(1);
        try (AdbMdns mdns = new AdbMdns(appContext, serviceType, service -> {
            if (!service.isLost()) {
                found.set(service);
                latch.countDown();
            }
        })) {
            mdns.start();
            if (!latch.await(timeoutMs, TimeUnit.MILLISECONDS)) {
                throw new AdbException("Timed out waiting for " + serviceType);
            }
        }
        AdbService service = found.get();
        if (service == null) {
            throw new AdbException("Timed out waiting for " + serviceType);
        }
        return service;
    }

    private AdbClient switchToTcp(AdbClient current, int currentPort, int tcpPort, Consumer<String> log)
            throws Exception {
        if (currentPort == tcpPort) {
            markTcpReady(tcpPort);
            return current;
        }
        progress(log, "Restarting in TCP mode port: " + tcpPort);
        try {
            current.tcpip(tcpPort);
        } finally {
            current.close();
        }
        progress(log, "Connecting on port " + tcpPort + "...");
        AdbClient tcp = connectWithRetry(LOOPBACK, tcpPort, 5);
        markTcpReady(tcpPort);
        progress(log, "Successfully connected on port " + tcpPort + "...");
        return tcp;
    }

    private AdbClient connectWithRetry(String host, int port, int attempts) throws Exception {
        Exception last = null;
        long delayMs = 0;
        for (int i = 0; i < attempts; i++) {
            if (delayMs > 0) {
                Thread.sleep(delayMs);
            }
            try {
                return connect(host, port);
            } catch (SocketTimeoutException e) {
                throw e;
            } catch (Exception e) {
                last = e;
                delayMs += 1000;
            }
        }
        if (last != null) {
            throw last;
        }
        throw new AdbException("Failed to connect " + host + ":" + port);
    }

    private AdbClient tryConnect(String host, int port, int timeoutMs) {
        try {
            return connect(host, port, timeoutMs);
        } catch (Exception e) {
            return null;
        }
    }

    private int systemTcpPort() {
        try {
            Class<?> clazz = Class.forName("android.os.SystemProperties");
            int port = (int) HiddenApiAccess.invoke(
                    clazz, null, "getInt", "service.adb.tcp.port", -1);
            if (port <= 0) {
                port = (int) HiddenApiAccess.invoke(
                        clazz, null, "getInt", "persist.adb.tcp.port", -1);
            }
            return port;
        } catch (Exception ignored) {
            return -1;
        }
    }

    private void markTcpReady(int port) {
        prefs().edit().putInt(PREF_TCP_PORT, port).putBoolean(PREF_TCP_READY, true).apply();
    }

    private SharedPreferences prefs() {
        return appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    private static void progress(Consumer<String> log, String message) {
        Log.i(TAG, message);
        if (log != null) {
            log.accept(message);
        }
    }
}
