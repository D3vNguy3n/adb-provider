package com.dnturbo.adb;

/** A shell command reached adbd but completed with a non-zero exit code. */
public class AdbCommandException extends AdbException {

    private final String command;
    private final int exitCode;
    private final String output;

    public AdbCommandException(String command, int exitCode, String output) {
        super(message(exitCode, output));
        this.command = command;
        this.exitCode = exitCode;
        this.output = output == null ? "" : output;
    }

    public String getCommand() {
        return command;
    }

    public int getExitCode() {
        return exitCode;
    }

    /** Combined stdout and stderr returned before the command exited. */
    public String getOutput() {
        return output;
    }

    private static String message(int exitCode, String output) {
        String detail = output == null ? "" : output.trim();
        return detail.isEmpty()
                ? "ADB command failed with exit code " + exitCode
                : detail;
    }
}
