package com.dnturbo.adb;

public class AdbException extends RuntimeException {

    public AdbException() {
    }

    public AdbException(String message) {
        super(message);
    }

    public AdbException(String message, Throwable cause) {
        super(message, cause);
    }

    public AdbException(Throwable cause) {
        super(cause);
    }
}
