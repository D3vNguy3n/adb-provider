package com.dnturbo.adb;

public interface AdbDiscoveryCallback {
    void onServiceChanged(AdbService service);
}
