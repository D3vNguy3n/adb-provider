package com.dnturbo.adb;

import android.content.SharedPreferences;
import android.util.Base64;

public class PreferenceAdbKeyStore implements AdbKeyStore {

    private static final String PREFERENCE_KEY = "adbkey";

    private final SharedPreferences preference;

    public PreferenceAdbKeyStore(SharedPreferences preference) {
        this.preference = preference;
    }

    @Override
    public void put(byte[] bytes) {
        preference.edit()
                .putString(PREFERENCE_KEY, Base64.encodeToString(bytes, Base64.NO_WRAP))
                .apply();
    }

    @Override
    public byte[] get() {
        if (!preference.contains(PREFERENCE_KEY)) {
            return null;
        }
        String value = preference.getString(PREFERENCE_KEY, null);
        if (value == null) {
            return null;
        }
        return Base64.decode(value, Base64.NO_WRAP);
    }
}
