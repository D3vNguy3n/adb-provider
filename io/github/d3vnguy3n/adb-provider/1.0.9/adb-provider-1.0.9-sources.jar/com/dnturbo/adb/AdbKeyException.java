package com.dnturbo.adb;

public class AdbKeyException extends AdbException {

    public AdbKeyException(Throwable cause) {
        super("Failed to create or load ADB key", cause);
    }
}
