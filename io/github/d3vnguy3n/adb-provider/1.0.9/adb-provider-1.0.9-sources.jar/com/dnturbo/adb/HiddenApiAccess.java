package com.dnturbo.adb;

import android.util.Property;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * Small, source-only bridge for the two non-SDK Android methods required by
 * wireless ADB. Keeping it here avoids a runtime dependency on HiddenApiBypass.
 */
final class HiddenApiAccess {

    @SuppressWarnings("rawtypes")
    private static final Property<Class, Method[]> DECLARED_METHODS =
            Property.of(Class.class, Method[].class, "DeclaredMethods");

    private HiddenApiAccess() {
    }

    static Object invoke(Class<?> owner, Object receiver, String name, Object... arguments)
            throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        for (Method method : DECLARED_METHODS.get(owner)) {
            if (!method.getName().equals(name)
                    || !accepts(method.getParameterTypes(), arguments)) {
                continue;
            }
            method.setAccessible(true);
            return method.invoke(receiver, arguments);
        }
        throw new NoSuchMethodException(owner.getName() + "." + name);
    }

    private static boolean accepts(Class<?>[] parameters, Object[] arguments) {
        if (parameters.length != arguments.length) {
            return false;
        }
        for (int i = 0; i < parameters.length; i++) {
            Class<?> parameter = parameters[i];
            Object argument = arguments[i];
            if (parameter.isPrimitive()) {
                if (!primitiveMatches(parameter, argument)) {
                    return false;
                }
            } else if (argument != null && !parameter.isInstance(argument)) {
                return false;
            }
        }
        return true;
    }

    private static boolean primitiveMatches(Class<?> parameter, Object argument) {
        return (parameter == int.class && argument instanceof Integer)
                || (parameter == long.class && argument instanceof Long)
                || (parameter == boolean.class && argument instanceof Boolean)
                || (parameter == byte.class && argument instanceof Byte)
                || (parameter == short.class && argument instanceof Short)
                || (parameter == char.class && argument instanceof Character)
                || (parameter == float.class && argument instanceof Float)
                || (parameter == double.class && argument instanceof Double);
    }
}
