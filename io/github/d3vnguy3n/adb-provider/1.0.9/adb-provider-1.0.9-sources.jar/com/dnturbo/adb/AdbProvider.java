package com.dnturbo.adb;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.database.Cursor;
import android.net.Uri;

/**
 * Initializes {@link AdbShell} before the host application's {@code Application.onCreate()}.
 *
 * <p>The provider is declared by the AAR manifest, so applications that depend on
 * {@code adb-provider} can call {@link AdbShell#get()} without manual initialization.
 * The host app can override the ADB/RSA device name with application metadata named
 * {@value #META_KEY_NAME}.
 */
public final class AdbProvider extends ContentProvider {

    public static final String META_KEY_NAME = "com.dnturbo.adb.KEY_NAME";
    public static final String DEFAULT_KEY_NAME = "AndroidAdbShell";

    private String keyName = DEFAULT_KEY_NAME;

    @Override
    public void attachInfo(Context context, ProviderInfo info) {
        String configured = readApplicationKeyName(context);
        if (configured == null && info != null && info.metaData != null) {
            configured = normalizeKeyName(info.metaData.getString(META_KEY_NAME));
        }
        if (configured != null) {
            keyName = configured;
        }
        super.attachInfo(context, info);
    }

    private static String readApplicationKeyName(Context context) {
        if (context == null) {
            return null;
        }
        try {
            ApplicationInfo applicationInfo = context.getPackageManager().getApplicationInfo(
                    context.getPackageName(), PackageManager.GET_META_DATA);
            if (applicationInfo.metaData == null) {
                return null;
            }
            return normalizeKeyName(applicationInfo.metaData.getString(META_KEY_NAME));
        } catch (PackageManager.NameNotFoundException ignored) {
            return null;
        }
    }

    private static String normalizeKeyName(String value) {
        if (value == null) {
            return null;
        }
        String normalized = value.trim();
        return normalized.isEmpty() ? null : normalized;
    }

    @Override
    public boolean onCreate() {
        Context context = getContext();
        if (context == null) {
            return false;
        }
        AdbShell.initialize(context, keyName);
        return true;
    }

    @Override
    public Cursor query(
            Uri uri,
            String[] projection,
            String selection,
            String[] selectionArgs,
            String sortOrder) {
        return null;
    }

    @Override
    public String getType(Uri uri) {
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }
}
