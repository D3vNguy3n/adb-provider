package com.dnturbo.adb;

public interface AdbKeyStore {
    void put(byte[] bytes);

    byte[] get();
}
