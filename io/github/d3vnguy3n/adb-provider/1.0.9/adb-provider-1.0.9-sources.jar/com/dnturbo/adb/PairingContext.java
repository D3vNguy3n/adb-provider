package com.dnturbo.adb;

final class PairingContext {

    private final long nativePtr;
    final byte[] msg;

    private PairingContext(long nativePtr) {
        this.nativePtr = nativePtr;
        this.msg = nativeMsg(nativePtr);
    }

    static PairingContext create(byte[] password) {
        AdbNative.ensureLoaded();
        long ptr = nativeConstructor(true, password);
        if (ptr == 0L) {
            return null;
        }
        return new PairingContext(ptr);
    }

    boolean initCipher(byte[] theirMsg) {
        return nativeInitCipher(nativePtr, theirMsg);
    }

    byte[] encrypt(byte[] in) {
        return nativeEncrypt(nativePtr, in);
    }

    byte[] decrypt(byte[] in) {
        return nativeDecrypt(nativePtr, in);
    }

    void destroy() {
        nativeDestroy(nativePtr);
    }

    private static native long nativeConstructor(boolean isClient, byte[] password);

    private native byte[] nativeMsg(long nativePtr);

    private native boolean nativeInitCipher(long nativePtr, byte[] theirMsg);

    private native byte[] nativeEncrypt(long nativePtr, byte[] inbuf);

    private native byte[] nativeDecrypt(long nativePtr, byte[] inbuf);

    private native void nativeDestroy(long nativePtr);
}
