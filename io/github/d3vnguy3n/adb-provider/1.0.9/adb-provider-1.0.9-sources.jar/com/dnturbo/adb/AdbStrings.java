package com.dnturbo.adb;

import android.content.Context;

import java.util.Locale;

/** Resolves optional copy-paste resources without depending on the host application's R class. */
final class AdbStrings {

    private AdbStrings() {
    }

    static String get(Context context, String name, String english, Object... arguments) {
        int id = context.getResources().getIdentifier(
                name, "string", context.getPackageName());
        if (id != 0) {
            return arguments.length == 0
                    ? context.getString(id)
                    : context.getString(id, arguments);
        }
        return arguments.length == 0
                ? english
                : String.format(Locale.getDefault(), english, arguments);
    }
}
