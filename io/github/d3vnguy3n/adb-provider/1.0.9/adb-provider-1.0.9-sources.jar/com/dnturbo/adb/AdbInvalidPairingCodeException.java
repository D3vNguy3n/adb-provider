package com.dnturbo.adb;

public class AdbInvalidPairingCodeException extends AdbException {

    public AdbInvalidPairingCodeException() {
        super("Invalid pairing code");
    }
}
