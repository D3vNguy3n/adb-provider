package com.dnturbo.adb;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPublicKey;

/** Builds the small self-signed certificate required by ADB TLS without Bouncy Castle. */
final class AdbCertificate {

    private static final byte[] SHA256_WITH_RSA_OID = new byte[]{
            0x2a, (byte) 0x86, 0x48, (byte) 0x86, (byte) 0xf7, 0x0d, 0x01, 0x01, 0x0b
    };
    private static final byte[] COMMON_NAME_OID = new byte[]{0x55, 0x04, 0x03};

    private AdbCertificate() {
    }

    static X509Certificate create(RSAPublicKey publicKey, PrivateKey privateKey) throws Exception {
        byte[] algorithm = sequence(objectIdentifier(SHA256_WITH_RSA_OID), value(0x05, new byte[0]));
        byte[] name = sequence(set(sequence(
                objectIdentifier(COMMON_NAME_OID),
                value(0x0c, "00".getBytes(StandardCharsets.UTF_8))
        )));
        byte[] validity = sequence(
                value(0x17, "700101000000Z".getBytes(StandardCharsets.US_ASCII)),
                value(0x18, "99991231235959Z".getBytes(StandardCharsets.US_ASCII))
        );
        byte[] version = value(0xa0, integer(BigInteger.valueOf(2)));
        byte[] tbsCertificate = sequence(
                version,
                integer(BigInteger.ONE),
                algorithm,
                name,
                validity,
                name,
                publicKey.getEncoded()
        );

        Signature signer = Signature.getInstance("SHA256withRSA");
        signer.initSign(privateKey);
        signer.update(tbsCertificate);
        byte[] signature = signer.sign();

        byte[] encoded = sequence(tbsCertificate, algorithm, bitString(signature));
        return (X509Certificate) CertificateFactory.getInstance("X.509")
                .generateCertificate(new ByteArrayInputStream(encoded));
    }

    private static byte[] sequence(byte[]... values) {
        return value(0x30, join(values));
    }

    private static byte[] set(byte[]... values) {
        return value(0x31, join(values));
    }

    private static byte[] integer(BigInteger number) {
        return value(0x02, number.toByteArray());
    }

    private static byte[] objectIdentifier(byte[] identifier) {
        return value(0x06, identifier);
    }

    private static byte[] bitString(byte[] bytes) {
        byte[] content = new byte[bytes.length + 1];
        System.arraycopy(bytes, 0, content, 1, bytes.length);
        return value(0x03, content);
    }

    private static byte[] value(int tag, byte[] content) {
        ByteArrayOutputStream output = new ByteArrayOutputStream(content.length + 6);
        output.write(tag);
        writeLength(output, content.length);
        output.write(content, 0, content.length);
        return output.toByteArray();
    }

    private static void writeLength(ByteArrayOutputStream output, int length) {
        if (length < 0x80) {
            output.write(length);
            return;
        }
        int bytes = 0;
        for (int value = length; value != 0; value >>>= 8) {
            bytes++;
        }
        output.write(0x80 | bytes);
        for (int shift = (bytes - 1) * 8; shift >= 0; shift -= 8) {
            output.write((length >>> shift) & 0xff);
        }
    }

    private static byte[] join(byte[]... values) {
        int length = 0;
        for (byte[] value : values) {
            length += value.length;
        }
        byte[] joined = new byte[length];
        int offset = 0;
        for (byte[] value : values) {
            System.arraycopy(value, 0, joined, offset, value.length);
            offset += value.length;
        }
        return joined;
    }
}
