package com.dnturbo.adb;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

final class AdbMessage {

    static final int HEADER_LENGTH = 24;

    final int command;
    final int arg0;
    final int arg1;
    final int dataLength;
    final int dataCrc32;
    final int magic;
    final byte[] data;

    AdbMessage(int command, int arg0, int arg1, int dataLength, int dataCrc32, int magic, byte[] data) {
        this.command = command;
        this.arg0 = arg0;
        this.arg1 = arg1;
        this.dataLength = dataLength;
        this.dataCrc32 = dataCrc32;
        this.magic = magic;
        this.data = data;
    }

    AdbMessage(int command, int arg0, int arg1, String data) {
        this(command, arg0, arg1, (data + "\0").getBytes());
    }

    AdbMessage(int command, int arg0, int arg1, byte[] data) {
        this(
                command,
                arg0,
                arg1,
                data != null ? data.length : 0,
                crc32(data),
                (int) (command ^ 0xFFFFFFFFL),
                data
        );
    }

    boolean validate() {
        if (command != (magic ^ -1)) {
            return false;
        }
        return dataLength == 0 || crc32(data) == dataCrc32;
    }

    void validateOrThrow() {
        if (!validate()) {
            throw new IllegalArgumentException("bad message " + toStringShort());
        }
    }

    byte[] toByteArray() {
        int length = HEADER_LENGTH + (data != null ? data.length : 0);
        ByteBuffer buffer = ByteBuffer.allocate(length).order(ByteOrder.LITTLE_ENDIAN);
        buffer.putInt(command);
        buffer.putInt(arg0);
        buffer.putInt(arg1);
        buffer.putInt(dataLength);
        buffer.putInt(dataCrc32);
        buffer.putInt(magic);
        if (data != null) {
            buffer.put(data);
        }
        return buffer.array();
    }

    String toStringShort() {
        String commandString;
        switch (command) {
            case AdbProtocol.A_SYNC:
                commandString = "A_SYNC";
                break;
            case AdbProtocol.A_CNXN:
                commandString = "A_CNXN";
                break;
            case AdbProtocol.A_AUTH:
                commandString = "A_AUTH";
                break;
            case AdbProtocol.A_OPEN:
                commandString = "A_OPEN";
                break;
            case AdbProtocol.A_OKAY:
                commandString = "A_OKAY";
                break;
            case AdbProtocol.A_CLSE:
                commandString = "A_CLSE";
                break;
            case AdbProtocol.A_WRTE:
                commandString = "A_WRTE";
                break;
            case AdbProtocol.A_STLS:
                commandString = "A_STLS";
                break;
            default:
                commandString = Integer.toString(command);
                break;
        }
        return "command=" + commandString
                + ", arg0=" + arg0
                + ", arg1=" + arg1
                + ", data_length=" + dataLength
                + ", data_crc32=" + dataCrc32
                + ", magic=" + magic;
    }

    private static int crc32(byte[] data) {
        if (data == null) {
            return 0;
        }
        int res = 0;
        for (byte b : data) {
            res += b >= 0 ? b : b + 256;
        }
        return res;
    }
}
