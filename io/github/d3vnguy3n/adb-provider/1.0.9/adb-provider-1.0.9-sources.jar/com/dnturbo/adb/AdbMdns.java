package com.dnturbo.adb;

import android.annotation.TargetApi;
import android.content.Context;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.util.Log;

import java.io.Closeable;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.SocketException;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

@TargetApi(Build.VERSION_CODES.R)
public class AdbMdns implements Closeable {

    public static final String TLS_CONNECT = "_adb-tls-connect._tcp";
    public static final String TLS_PAIRING = "_adb-tls-pairing._tcp";
    public static final String TAG = "AdbMdns";

    private final String serviceType;
    private final AdbDiscoveryCallback observer;
    private final NsdManager nsdManager;
    private final WifiManager.MulticastLock multicastLock;
    private final DiscoveryListener listener = new DiscoveryListener();

    private boolean registered;
    private boolean running;
    private boolean resolving;
    private String serviceName;
    private NsdServiceInfo pendingResolve;

    public AdbMdns(Context context, String serviceType, AdbDiscoveryCallback observer) {
        this.serviceType = serviceType;
        this.observer = observer;
        Context app = context.getApplicationContext();
        this.nsdManager = app.getSystemService(NsdManager.class);
        WifiManager wifi = (WifiManager) app.getSystemService(Context.WIFI_SERVICE);
        if (wifi != null) {
            multicastLock = wifi.createMulticastLock("adb-mdns");
            multicastLock.setReferenceCounted(false);
        } else {
            multicastLock = null;
        }
    }

    public void start() {
        if (running) {
            return;
        }
        running = true;
        if (multicastLock != null) {
            multicastLock.acquire();
        }
        if (!registered) {
            nsdManager.discoverServices(serviceType, NsdManager.PROTOCOL_DNS_SD, listener);
        }
    }

    public void stop() {
        if (!running) {
            return;
        }
        running = false;
        if (registered) {
            nsdManager.stopServiceDiscovery(listener);
        }
        if (multicastLock != null && multicastLock.isHeld()) {
            multicastLock.release();
        }
    }

    @Override
    public void close() {
        stop();
    }

    private void onDiscoveryStart() {
        registered = true;
    }

    private void onDiscoveryStop() {
        registered = false;
    }

    private void onServiceFound(NsdServiceInfo info) {
        synchronized (this) {
            if (resolving) {
                pendingResolve = info;
                return;
            }
            resolving = true;
        }
        resolveService(info);
    }

    private void onServiceLost(NsdServiceInfo info) {
        if (info.getServiceName() != null && info.getServiceName().equals(serviceName)) {
            observer.onServiceChanged(new AdbService("", -1));
        }
    }

    private void onServiceResolved(NsdServiceInfo resolvedService) {
        int port = resolvedService.getPort();
        if (port <= 0) {
            return;
        }
        for (InetAddress address : hostAddresses(resolvedService)) {
            String host = address.getHostAddress();
            if (running && isLocalAddress(address) && isPortAvailable(host, port)) {
                publishResolvedService(resolvedService, host, port);
                return;
            }
        }

        // Wireless debugging is hosted by adbd on this device. Some Android builds
        // return only an unusable/scoped IPv6 address from NSD even though the pairing
        // socket is also listening on loopback, so use loopback as a safe fallback.
        if (running && isPortAvailable(WirelessAdb.LOOPBACK, port)) {
            publishResolvedService(resolvedService, WirelessAdb.LOOPBACK, port);
        }
    }

    private List<InetAddress> hostAddresses(NsdServiceInfo info) {
        if (Build.VERSION.SDK_INT >= 34) {
            List<InetAddress> addresses = info.getHostAddresses();
            return addresses == null ? Collections.emptyList() : addresses;
        }
        InetAddress host = info.getHost();
        return host == null ? Collections.emptyList() : Collections.singletonList(host);
    }

    private boolean isLocalAddress(InetAddress host) {
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            if (interfaces == null) {
                return false;
            }
            while (interfaces.hasMoreElements()) {
                NetworkInterface nif = interfaces.nextElement();
                Enumeration<InetAddress> addresses = nif.getInetAddresses();
                while (addresses.hasMoreElements()) {
                    if (host.equals(addresses.nextElement())) {
                        return true;
                    }
                }
            }
        } catch (SocketException ignored) {
        }
        return false;
    }

    private void publishResolvedService(NsdServiceInfo service, String host, int port) {
        serviceName = service.getServiceName();
        observer.onServiceChanged(new AdbService(host, port));
    }

    private void resolveService(NsdServiceInfo info) {
        try {
            nsdManager.resolveService(info, new ResolveListener());
        } catch (Throwable error) {
            Log.w(TAG, "resolveService failed: " + info.getServiceName(), error);
            onResolveFinished();
        }
    }

    private void onResolveFinished() {
        NsdServiceInfo next = null;
        synchronized (this) {
            resolving = false;
            if (running && pendingResolve != null) {
                next = pendingResolve;
                pendingResolve = null;
                resolving = true;
            }
        }
        if (next != null) {
            resolveService(next);
        }
    }

    private boolean isPortAvailable(String host, int port) {
        try (ServerSocket socket = new ServerSocket()) {
            socket.bind(new InetSocketAddress(host, port), 1);
            return false;
        } catch (IOException e) {
            return true;
        }
    }

    private class DiscoveryListener implements NsdManager.DiscoveryListener {
        @Override
        public void onDiscoveryStarted(String serviceType) {
            Log.v(TAG, "onDiscoveryStarted: " + serviceType);
            onDiscoveryStart();
        }

        @Override
        public void onStartDiscoveryFailed(String serviceType, int errorCode) {
            Log.w(TAG, "onStartDiscoveryFailed: " + serviceType + ", " + errorCode);
        }

        @Override
        public void onDiscoveryStopped(String serviceType) {
            Log.v(TAG, "onDiscoveryStopped: " + serviceType);
            onDiscoveryStop();
        }

        @Override
        public void onStopDiscoveryFailed(String serviceType, int errorCode) {
            Log.w(TAG, "onStopDiscoveryFailed: " + serviceType + ", " + errorCode);
        }

        @Override
        public void onServiceFound(NsdServiceInfo serviceInfo) {
            Log.v(TAG, "onServiceFound: " + serviceInfo.getServiceName());
            AdbMdns.this.onServiceFound(serviceInfo);
        }

        @Override
        public void onServiceLost(NsdServiceInfo serviceInfo) {
            Log.v(TAG, "onServiceLost: " + serviceInfo.getServiceName());
            AdbMdns.this.onServiceLost(serviceInfo);
        }
    }

    private class ResolveListener implements NsdManager.ResolveListener {
        @Override
        public void onResolveFailed(NsdServiceInfo nsdServiceInfo, int i) {
            Log.w(TAG, "onResolveFailed: " + nsdServiceInfo.getServiceName() + ", " + i);
            onResolveFinished();
        }

        @Override
        public void onServiceResolved(NsdServiceInfo nsdServiceInfo) {
            try {
                AdbMdns.this.onServiceResolved(nsdServiceInfo);
            } finally {
                onResolveFinished();
            }
        }
    }
}
