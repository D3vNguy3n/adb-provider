package com.dnturbo.adb;

final class AdbNative {

    private static volatile boolean loaded;

    private AdbNative() {
    }

    static void ensureLoaded() {
        if (loaded) {
            return;
        }
        synchronized (AdbNative.class) {
            if (loaded) {
                return;
            }
            System.loadLibrary("adb");
            loaded = true;
        }
    }
}
