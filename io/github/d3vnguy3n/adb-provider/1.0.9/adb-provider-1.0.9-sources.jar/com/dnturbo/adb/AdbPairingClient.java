package com.dnturbo.adb;

import android.util.Log;

import java.io.Closeable;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import javax.net.ssl.SSLSocket;

public class AdbPairingClient implements Closeable {

    private static final String TAG = "AdbPairClient";
    private static final byte CURRENT_KEY_HEADER_VERSION = 1;
    private static final byte MIN_SUPPORTED_KEY_HEADER_VERSION = 1;
    private static final byte MAX_SUPPORTED_KEY_HEADER_VERSION = 1;
    private static final int MAX_PEER_INFO_SIZE = 8192;
    private static final int MAX_PAYLOAD_SIZE = MAX_PEER_INFO_SIZE * 2;
    private static final String EXPORTED_KEY_LABEL = "adb-label\0";
    private static final int EXPORTED_KEY_SIZE = 64;
    private static final int PAIRING_PACKET_HEADER_SIZE = 6;

    private enum State {
        READY,
        EXCHANGING_MSGS,
        EXCHANGING_PEER_INFO,
        STOPPED
    }

    private final String host;
    private final int port;
    private final String pairCode;
    private final AdbKey key;
    private final PeerInfo peerInfo;

    private Socket socket;
    private DataInputStream inputStream;
    private DataOutputStream outputStream;
    private PairingContext pairingContext;
    private State state = State.READY;

    public AdbPairingClient(String host, int port, String pairCode, AdbKey key) {
        this.host = host;
        this.port = port;
        this.pairCode = pairCode;
        this.key = key;
        this.peerInfo = new PeerInfo(PeerInfo.TYPE_ADB_RSA_PUB_KEY, key.getAdbPublicKey());
    }

    public boolean start() throws Exception {
        AdbNative.ensureLoaded();
        setupTlsConnection();

        state = State.EXCHANGING_MSGS;
        if (!doExchangeMsgs()) {
            state = State.STOPPED;
            return false;
        }

        state = State.EXCHANGING_PEER_INFO;
        if (!doExchangePeerInfo()) {
            state = State.STOPPED;
            return false;
        }

        state = State.STOPPED;
        return true;
    }

    private void setupTlsConnection() throws Exception {
        socket = new Socket(host, port);
        socket.setTcpNoDelay(true);

        SSLSocket sslSocket = (SSLSocket) key.getSslContext().getSocketFactory()
                .createSocket(socket, host, port, true);
        sslSocket.startHandshake();
        Log.d(TAG, "Handshake succeeded.");

        inputStream = new DataInputStream(sslSocket.getInputStream());
        outputStream = new DataOutputStream(sslSocket.getOutputStream());

        byte[] pairCodeBytes = pairCode.getBytes();
        byte[] keyMaterial = exportKeyingMaterial(sslSocket, EXPORTED_KEY_LABEL, null, EXPORTED_KEY_SIZE);
        byte[] passwordBytes = new byte[pairCodeBytes.length + keyMaterial.length];
        System.arraycopy(pairCodeBytes, 0, passwordBytes, 0, pairCodeBytes.length);
        System.arraycopy(keyMaterial, 0, passwordBytes, pairCodeBytes.length, keyMaterial.length);

        pairingContext = PairingContext.create(passwordBytes);
        if (pairingContext == null) {
            throw new IllegalStateException("Unable to create PairingContext.");
        }
    }

    private PairingPacketHeader createHeader(byte type, int payloadSize) {
        return new PairingPacketHeader(CURRENT_KEY_HEADER_VERSION, type, payloadSize);
    }

    private PairingPacketHeader readHeader() throws Exception {
        byte[] bytes = new byte[PAIRING_PACKET_HEADER_SIZE];
        inputStream.readFully(bytes);
        ByteBuffer buffer = ByteBuffer.wrap(bytes).order(ByteOrder.BIG_ENDIAN);
        return PairingPacketHeader.readFrom(buffer);
    }

    private void writeHeader(PairingPacketHeader header, byte[] payload) throws Exception {
        ByteBuffer buffer = ByteBuffer.allocate(PAIRING_PACKET_HEADER_SIZE).order(ByteOrder.BIG_ENDIAN);
        header.writeTo(buffer);
        outputStream.write(buffer.array());
        outputStream.write(payload);
        Log.d(TAG, "write payload, size=" + payload.length);
    }

    private boolean doExchangeMsgs() throws Exception {
        byte[] msg = pairingContext.msg;
        writeHeader(createHeader(PairingPacketHeader.TYPE_SPAKE2_MSG, msg.length), msg);

        PairingPacketHeader theirHeader = readHeader();
        if (theirHeader == null || theirHeader.type != PairingPacketHeader.TYPE_SPAKE2_MSG) {
            return false;
        }

        byte[] theirMessage = new byte[theirHeader.payload];
        inputStream.readFully(theirMessage);
        return pairingContext.initCipher(theirMessage);
    }

    private boolean doExchangePeerInfo() throws Exception {
        ByteBuffer buf = ByteBuffer.allocate(MAX_PEER_INFO_SIZE).order(ByteOrder.BIG_ENDIAN);
        peerInfo.writeTo(buf);

        byte[] outbuf = pairingContext.encrypt(buf.array());
        if (outbuf == null) {
            return false;
        }
        writeHeader(createHeader(PairingPacketHeader.TYPE_PEER_INFO, outbuf.length), outbuf);

        PairingPacketHeader theirHeader = readHeader();
        if (theirHeader == null || theirHeader.type != PairingPacketHeader.TYPE_PEER_INFO) {
            return false;
        }

        byte[] theirMessage = new byte[theirHeader.payload];
        inputStream.readFully(theirMessage);

        byte[] decrypted = pairingContext.decrypt(theirMessage);
        if (decrypted == null) {
            throw new AdbInvalidPairingCodeException();
        }
        if (decrypted.length != MAX_PEER_INFO_SIZE) {
            Log.e(TAG, "Got size=" + decrypted.length + " PeerInfo.size=" + MAX_PEER_INFO_SIZE);
            return false;
        }
        PeerInfo.readFrom(ByteBuffer.wrap(decrypted));
        return true;
    }

    @Override
    public void close() {
        try {
            if (inputStream != null) {
                inputStream.close();
            }
        } catch (Throwable ignored) {
        }
        try {
            if (outputStream != null) {
                outputStream.close();
            }
        } catch (Throwable ignored) {
        }
        try {
            if (socket != null) {
                socket.close();
            }
        } catch (Exception ignored) {
        }
        if (state != State.READY && pairingContext != null) {
            pairingContext.destroy();
        }
    }

    private static byte[] exportKeyingMaterial(SSLSocket sslSocket, String label, byte[] context, int length)
            throws Exception {
        Class<?> conscrypt = Class.forName("com.android.org.conscrypt.Conscrypt");
        return (byte[]) HiddenApiAccess.invoke(
                conscrypt, null, "exportKeyingMaterial", sslSocket, label, context, length);
    }

    private static final class PeerInfo {
        static final byte TYPE_ADB_RSA_PUB_KEY = 0;

        final byte type;
        final byte[] data = new byte[MAX_PEER_INFO_SIZE - 1];

        PeerInfo(byte type, byte[] data) {
            this.type = type;
            int copy = Math.min(data.length, this.data.length);
            System.arraycopy(data, 0, this.data, 0, copy);
        }

        void writeTo(ByteBuffer buffer) {
            buffer.put(type);
            buffer.put(data);
            Log.d(TAG, "write PeerInfo type=" + type);
        }

        static PeerInfo readFrom(ByteBuffer buffer) {
            byte type = buffer.get();
            byte[] data = new byte[MAX_PEER_INFO_SIZE - 1];
            buffer.get(data);
            return new PeerInfo(type, data);
        }
    }

    private static final class PairingPacketHeader {
        static final byte TYPE_SPAKE2_MSG = 0;
        static final byte TYPE_PEER_INFO = 1;

        final byte version;
        final byte type;
        final int payload;

        PairingPacketHeader(byte version, byte type, int payload) {
            this.version = version;
            this.type = type;
            this.payload = payload;
        }

        void writeTo(ByteBuffer buffer) {
            buffer.put(version);
            buffer.put(type);
            buffer.putInt(payload);
            Log.d(TAG, "write PairingPacketHeader " + toStringShort());
        }

        String toStringShort() {
            return "version=" + version + ", type=" + type + ", payload=" + payload;
        }

        static PairingPacketHeader readFrom(ByteBuffer buffer) {
            byte version = buffer.get();
            byte type = buffer.get();
            int payload = buffer.getInt();

            if (version < MIN_SUPPORTED_KEY_HEADER_VERSION || version > MAX_SUPPORTED_KEY_HEADER_VERSION) {
                Log.e(TAG, "PairingPacketHeader version mismatch (us=" + CURRENT_KEY_HEADER_VERSION + " them=" + version + ")");
                return null;
            }
            if (type != TYPE_SPAKE2_MSG && type != TYPE_PEER_INFO) {
                Log.e(TAG, "Unknown PairingPacket type=" + type);
                return null;
            }
            if (payload <= 0 || payload > MAX_PAYLOAD_SIZE) {
                Log.e(TAG, "header payload not within a safe payload size (size=" + payload + ")");
                return null;
            }
            PairingPacketHeader header = new PairingPacketHeader(version, type, payload);
            Log.d(TAG, "read PairingPacketHeader " + header.toStringShort());
            return header;
        }
    }
}
