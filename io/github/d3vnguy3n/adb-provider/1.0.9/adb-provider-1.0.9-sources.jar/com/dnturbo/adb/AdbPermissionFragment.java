package com.dnturbo.adb;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Build;

/** Internal fragment used to receive a runtime-permission result without AndroidX. */
@SuppressWarnings("deprecation")
@TargetApi(Build.VERSION_CODES.R)
public final class AdbPermissionFragment extends Fragment {

    interface Callback {
        void onResult(boolean granted);
    }

    private static final int REQUEST_CODE = 1;

    private String permission;
    private Callback callback;
    private boolean requested;

    public AdbPermissionFragment() {
    }

    static void request(Activity activity, String permission, Callback callback) {
        AdbPermissionFragment fragment = new AdbPermissionFragment();
        fragment.permission = permission;
        fragment.callback = callback;
        String tag = "com.dnturbo.adb.permission." + System.nanoTime();
        try {
            FragmentManager manager = activity.getFragmentManager();
            manager.beginTransaction().add(fragment, tag).commitAllowingStateLoss();
            manager.executePendingTransactions();
        } catch (Throwable error) {
            fragment.callback = null;
            callback.onResult(false);
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
        if (!requested && permission != null) {
            requested = true;
            requestPermissions(new String[]{permission}, REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_CODE) {
            return;
        }
        boolean granted = grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        Callback result = callback;
        callback = null;
        if (isAdded()) {
            getFragmentManager().beginTransaction().remove(this).commitAllowingStateLoss();
        }
        if (result != null) {
            result.onResult(granted);
        }
    }
}
