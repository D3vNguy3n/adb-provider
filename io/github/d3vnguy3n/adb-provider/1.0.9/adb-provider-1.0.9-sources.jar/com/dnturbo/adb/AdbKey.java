package com.dnturbo.adb;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.math.BigInteger;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.Principal;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.RSAKeyGenParameterSpec;
import java.security.spec.RSAPublicKeySpec;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.GCMParameterSpec;
import javax.net.ssl.SSLContext;
import javax.net.ssl.X509ExtendedKeyManager;
import javax.net.ssl.X509TrustManager;

@TargetApi(Build.VERSION_CODES.R)
public class AdbKey {

    private static final String ANDROID_KEYSTORE = "AndroidKeyStore";
    private static final String ENCRYPTION_KEY_ALIAS = "_adbkey_encryption_key_";
    private static final String TRANSFORMATION = "AES/GCM/NoPadding";
    private static final int IV_SIZE_IN_BYTES = 12;
    private static final int TAG_SIZE_IN_BYTES = 16;
    private static final int ANDROID_PUBKEY_MODULUS_SIZE = 2048 / 8;
    private static final int ANDROID_PUBKEY_MODULUS_SIZE_WORDS = ANDROID_PUBKEY_MODULUS_SIZE / 4;
    private static final int RSA_PUBLIC_KEY_SIZE = 524;

    private static final byte[] PADDING = new byte[]{
            0x00, 0x01, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
            -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
            -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
            -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
            -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
            -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
            -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
            -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
            -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
            -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
            -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
            -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
            -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
            -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
            -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
            -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
            -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0x00,
            0x30, 0x21, 0x30, 0x09, 0x06, 0x05, 0x2b, 0x0e, 0x03, 0x02, 0x1a, 0x05, 0x00,
            0x04, 0x14
    };

    private final Key encryptionKey;
    private final RSAPrivateKey privateKey;
    private final RSAPublicKey publicKey;
    private final X509Certificate certificate;
    private final byte[] adbPublicKey;
    private SSLContext sslContext;

    public AdbKey(AdbKeyStore adbKeyStore, String name) {
        Key generated = getOrCreateEncryptionKey();
        if (generated == null) {
            throw new IllegalStateException("Failed to generate encryption key with AndroidKeyManager.");
        }
        this.encryptionKey = generated;
        this.privateKey = getOrCreatePrivateKey(adbKeyStore);
        try {
            this.publicKey = (RSAPublicKey) KeyFactory.getInstance("RSA")
                    .generatePublic(new RSAPublicKeySpec(privateKey.getModulus(), RSAKeyGenParameterSpec.F4));
            this.certificate = AdbCertificate.create(publicKey, privateKey);
        } catch (Exception e) {
            throw new IllegalStateException("Failed to build ADB certificate", e);
        }
        this.adbPublicKey = adbEncoded(publicKey, name);
    }

    public byte[] getAdbPublicKey() {
        return adbPublicKey;
    }

    public byte[] sign(byte[] data) {
        try {
            Cipher cipher = Cipher.getInstance("RSA/ECB/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, privateKey);
            cipher.update(PADDING);
            return cipher.doFinal(data);
        } catch (Exception e) {
            throw new IllegalStateException("Failed to sign ADB token", e);
        }
    }

    public synchronized SSLContext getSslContext() {
        if (sslContext == null) {
            try {
                SSLContext context = SSLContext.getInstance("TLSv1.3");
                context.init(new javax.net.ssl.KeyManager[]{keyManager()}, new javax.net.ssl.TrustManager[]{trustManager()}, new SecureRandom());
                sslContext = context;
            } catch (Exception e) {
                throw new IllegalStateException("Failed to create TLS context", e);
            }
        }
        return sslContext;
    }

    private Key getOrCreateEncryptionKey() {
        try {
            KeyStore keyStore = KeyStore.getInstance(ANDROID_KEYSTORE);
            keyStore.load(null);
            Key existing = keyStore.getKey(ENCRYPTION_KEY_ALIAS, null);
            if (existing != null) {
                return existing;
            }
            KeyGenParameterSpec parameterSpec = new KeyGenParameterSpec.Builder(
                    ENCRYPTION_KEY_ALIAS,
                    KeyProperties.PURPOSE_DECRYPT | KeyProperties.PURPOSE_ENCRYPT
            )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build();
            KeyGenerator keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE);
            keyGenerator.init(parameterSpec);
            return keyGenerator.generateKey();
        } catch (Exception e) {
            return null;
        }
    }

    private byte[] encrypt(byte[] plaintext, byte[] aad) {
        if (plaintext.length > Integer.MAX_VALUE - IV_SIZE_IN_BYTES - TAG_SIZE_IN_BYTES) {
            return null;
        }
        try {
            byte[] ciphertext = new byte[IV_SIZE_IN_BYTES + plaintext.length + TAG_SIZE_IN_BYTES];
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.ENCRYPT_MODE, encryptionKey);
            cipher.updateAAD(aad);
            cipher.doFinal(plaintext, 0, plaintext.length, ciphertext, IV_SIZE_IN_BYTES);
            System.arraycopy(cipher.getIV(), 0, ciphertext, 0, IV_SIZE_IN_BYTES);
            return ciphertext;
        } catch (Exception e) {
            return null;
        }
    }

    private byte[] decrypt(byte[] ciphertext, byte[] aad) {
        if (ciphertext.length < IV_SIZE_IN_BYTES + TAG_SIZE_IN_BYTES) {
            return null;
        }
        try {
            GCMParameterSpec params = new GCMParameterSpec(8 * TAG_SIZE_IN_BYTES, ciphertext, 0, IV_SIZE_IN_BYTES);
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.DECRYPT_MODE, encryptionKey, params);
            cipher.updateAAD(aad);
            return cipher.doFinal(ciphertext, IV_SIZE_IN_BYTES, ciphertext.length - IV_SIZE_IN_BYTES);
        } catch (Exception e) {
            return null;
        }
    }

    private RSAPrivateKey getOrCreatePrivateKey(AdbKeyStore adbKeyStore) {
        RSAPrivateKey loaded = null;
        byte[] aad = new byte[16];
        byte[] adbkey = "adbkey".getBytes();
        System.arraycopy(adbkey, 0, aad, 0, adbkey.length);

        byte[] ciphertext = adbKeyStore.get();
        if (ciphertext != null) {
            try {
                byte[] plaintext = decrypt(ciphertext, aad);
                loaded = (RSAPrivateKey) KeyFactory.getInstance("RSA")
                        .generatePrivate(new PKCS8EncodedKeySpec(plaintext));
            } catch (Exception ignored) {
            }
        }
        if (loaded == null) {
            try {
                KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_RSA);
                keyPairGenerator.initialize(new RSAKeyGenParameterSpec(2048, RSAKeyGenParameterSpec.F4));
                KeyPair keyPair = keyPairGenerator.generateKeyPair();
                loaded = (RSAPrivateKey) keyPair.getPrivate();
                byte[] encrypted = encrypt(loaded.getEncoded(), aad);
                if (encrypted != null) {
                    adbKeyStore.put(encrypted);
                }
            } catch (Exception e) {
                throw new IllegalStateException("Failed to generate ADB RSA key", e);
            }
        }
        return loaded;
    }

    private X509ExtendedKeyManager keyManager() {
        return new X509ExtendedKeyManager() {
            private final String alias = "key";

            @Override
            public String chooseClientAlias(String[] keyTypes, Principal[] issuers, Socket socket) {
                if (keyTypes == null) {
                    return null;
                }
                for (String keyType : keyTypes) {
                    if ("RSA".equals(keyType)) {
                        return alias;
                    }
                }
                return null;
            }

            @Override
            public X509Certificate[] getCertificateChain(String alias) {
                return this.alias.equals(alias) ? new X509Certificate[]{certificate} : null;
            }

            @Override
            public PrivateKey getPrivateKey(String alias) {
                return this.alias.equals(alias) ? privateKey : null;
            }

            @Override
            public String[] getClientAliases(String keyType, Principal[] issuers) {
                return null;
            }

            @Override
            public String[] getServerAliases(String keyType, Principal[] issuers) {
                return null;
            }

            @Override
            public String chooseServerAlias(String keyType, Principal[] issuers, Socket socket) {
                return null;
            }
        };
    }

    private X509TrustManager trustManager() {
        return new X509TrustManager() {
            @SuppressLint("TrustAllX509TrustManager")
            @Override
            public void checkClientTrusted(X509Certificate[] chain, String authType) {
            }

            @SuppressLint("TrustAllX509TrustManager")
            @Override
            public void checkServerTrusted(X509Certificate[] chain, String authType) {
            }

            @Override
            public X509Certificate[] getAcceptedIssuers() {
                return new X509Certificate[0];
            }
        };
    }

    private static int[] toAdbEncoded(BigInteger value) {
        int[] encoded = new int[ANDROID_PUBKEY_MODULUS_SIZE_WORDS];
        BigInteger r32 = BigInteger.ZERO.setBit(32);
        BigInteger tmp = value.add(BigInteger.ZERO);
        for (int i = 0; i < ANDROID_PUBKEY_MODULUS_SIZE_WORDS; i++) {
            BigInteger[] out = tmp.divideAndRemainder(r32);
            tmp = out[0];
            encoded[i] = out[1].intValue();
        }
        return encoded;
    }

    private static byte[] adbEncoded(RSAPublicKey publicKey, String name) {
        BigInteger r32 = BigInteger.ZERO.setBit(32);
        BigInteger n0inv = publicKey.getModulus().remainder(r32).modInverse(r32).negate();
        BigInteger r = BigInteger.ZERO.setBit(ANDROID_PUBKEY_MODULUS_SIZE * 8);
        BigInteger rr = r.modPow(BigInteger.valueOf(2), publicKey.getModulus());

        ByteBuffer buffer = ByteBuffer.allocate(RSA_PUBLIC_KEY_SIZE).order(ByteOrder.LITTLE_ENDIAN);
        buffer.putInt(ANDROID_PUBKEY_MODULUS_SIZE_WORDS);
        buffer.putInt(n0inv.intValue());
        for (int word : toAdbEncoded(publicKey.getModulus())) {
            buffer.putInt(word);
        }
        for (int word : toAdbEncoded(rr)) {
            buffer.putInt(word);
        }
        buffer.putInt(publicKey.getPublicExponent().intValue());

        byte[] base64Bytes = Base64.encode(buffer.array(), Base64.NO_WRAP);
        byte[] nameBytes = (" " + name + "\0").getBytes();
        byte[] bytes = new byte[base64Bytes.length + nameBytes.length];
        System.arraycopy(base64Bytes, 0, bytes, 0, base64Bytes.length);
        System.arraycopy(nameBytes, 0, bytes, base64Bytes.length, nameBytes.length);
        return bytes;
    }
}
