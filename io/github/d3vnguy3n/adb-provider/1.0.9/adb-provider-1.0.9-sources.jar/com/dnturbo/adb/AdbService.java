package com.dnturbo.adb;

public final class AdbService {

    public final String host;
    public final int port;

    public AdbService(String host, int port) {
        this.host = host;
        this.port = port;
    }

    public boolean isLost() {
        return port <= 0;
    }

    @Override
    public String toString() {
        return host + ":" + port;
    }
}
