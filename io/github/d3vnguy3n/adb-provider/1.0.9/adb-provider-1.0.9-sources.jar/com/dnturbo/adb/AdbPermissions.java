package com.dnturbo.adb;

import android.content.Context;
import android.os.Build;

public final class AdbPermissions {

    private AdbPermissions() {
    }

    /** Runtime permission required for mDNS discovery / pairing. */
    public static String localNetworkPermission(Context context) {
        if (context == null) {
            throw new IllegalArgumentException("context == null");
        }
        if (Build.VERSION.SDK_INT >= 37
                && context.getApplicationInfo().targetSdkVersion >= 37) {
            return "android.permission.ACCESS_LOCAL_NETWORK";
        }
        return null;
    }

    /**
     * Returns the permission used by Android 17+, without checking the host app's
     * target SDK. Prefer {@link #localNetworkPermission(Context)}.
     */
    @Deprecated
    public static String localNetworkPermission() {
        if (Build.VERSION.SDK_INT >= 37) {
            return "android.permission.ACCESS_LOCAL_NETWORK";
        }
        return null;
    }
}
