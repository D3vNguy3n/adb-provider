package com.dnturbo.adb;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import java.io.Closeable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Notification flow for entering Android's six-digit ADB pairing code. */
public final class AdbPairingService extends Service {

    private static final String ACTION_START = "com.dnturbo.adb.action.START_PAIRING";
    private static final String ACTION_REPLY = "com.dnturbo.adb.action.REPLY_PAIRING";
    private static final String ACTION_STOP = "com.dnturbo.adb.action.STOP_PAIRING";
    private static final String EXTRA_GENERATION = "generation";
    private static final String EXTRA_KEY_NAME = "key_name";
    private static final String EXTRA_HOST = "host";
    private static final String EXTRA_PORT = "port";
    private static final String REMOTE_INPUT_CODE = "pairing_code";

    static final String CODE_CHANNEL = "com.dnturbo.adb.pairing_code";
    private static final int SERVICE_NOTIFICATION_ID = 0xadb1;
    private static final int LEGACY_CODE_NOTIFICATION_ID = 0xadb2;
    private static final int RESULT_NOTIFICATION_ID = 0xadb3;
    private static final long TIMEOUT_MS = 150_000L;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Runnable timeout = () -> fail(
            new AdbException(string("adb_pairing_timeout",
                    "Timed out waiting for the six-digit pairing service")));

    private WirelessAdb wirelessAdb;
    private Closeable discovery;
    private int generation = -1;
    private String keyName = "AndroidAdbShell";
    private boolean pairing;

    static void start(Context context, int generation, String keyName) {
        Intent intent = new Intent(context, AdbPairingService.class)
                .setAction(ACTION_START)
                .putExtra(EXTRA_GENERATION, generation)
                .putExtra(EXTRA_KEY_NAME, keyName);
        context.startService(intent);
    }

    static void stop(Context context) {
        context.stopService(new Intent(context, AdbPairingService.class));
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        if (manager != null) {
            manager.cancel(SERVICE_NOTIFICATION_ID);
        }
    }

    static boolean areNotificationsUsable(Context context) {
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        if (manager == null) {
            return false;
        }
        if (Build.VERSION.SDK_INT >= 24 && !manager.areNotificationsEnabled()) {
            return false;
        }
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = manager.getNotificationChannel(CODE_CHANNEL);
            return channel == null || channel.getImportance() != NotificationManager.IMPORTANCE_NONE;
        }
        return true;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannels();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            stopPairing();
            return START_NOT_STICKY;
        }

        String action = intent.getAction();
        generation = intent.getIntExtra(EXTRA_GENERATION, generation);
        keyName = intent.getStringExtra(EXTRA_KEY_NAME) == null
                ? keyName : intent.getStringExtra(EXTRA_KEY_NAME);
        ensureWirelessAdb();
        getSystemService(NotificationManager.class).cancel(RESULT_NOTIFICATION_ID);

        if (ACTION_STOP.equals(action)) {
            AdbShell.onNotificationPairingError(
                    generation,
                    AdbShell.ConnectionError.USER_CANCELLED,
                    new AdbException(string("adb_connection_cancelled", "Connection cancelled")));
            stopPairing();
            return START_NOT_STICKY;
        }

        if (ACTION_REPLY.equals(action)) {
            notifyService(workingNotification());
            String host = intent.getStringExtra(EXTRA_HOST);
            int port = intent.getIntExtra(EXTRA_PORT, -1);
            CharSequence input = "";
            android.os.Bundle results = RemoteInput.getResultsFromIntent(intent);
            if (results != null) {
                input = results.getCharSequence(REMOTE_INPUT_CODE, "");
            }
            pair(host, port, input == null ? "" : input.toString());
        } else {
            notifyService(searchingNotification());
            startDiscovery();
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        mainHandler.removeCallbacks(timeout);
        closeDiscovery();
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) {
            manager.cancel(SERVICE_NOTIFICATION_ID);
        }
        executor.shutdownNow();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void ensureWirelessAdb() {
        if (wirelessAdb == null) {
            wirelessAdb = WirelessAdb.create(this, keyName);
        }
    }

    private void startDiscovery() {
        pairing = false;
        closeDiscovery();
        mainHandler.removeCallbacks(timeout);
        mainHandler.postDelayed(timeout, TIMEOUT_MS);
        notifyService(searchingNotification());
        AdbShell.onNotificationPairingState(
                generation, AdbShell.ConnectionState.WAITING_FOR_PAIRING_CODE);
        try {
            discovery = wirelessAdb.discoverPairing(service -> mainHandler.post(() -> {
                if (pairing) {
                    return;
                }
                if (service.isLost()) {
                    notifyService(searchingNotification());
                } else {
                    showCodePrompt(service, string(
                            "adb_device_found", "Device found: %1$s", service));
                }
            }));
        } catch (Throwable error) {
            fail(error);
        }
    }

    private void pair(String host, int port, String code) {
        if (pairing) {
            return;
        }
        if (host == null || port <= 0) {
            fail(new AdbException(string("adb_pairing_service_unavailable",
                    "Pairing service is no longer available")));
            return;
        }
        String normalized = code.trim();
        AdbService endpoint = new AdbService(host, port);
        if (!normalized.matches("\\d{6}")) {
            showCodePrompt(endpoint, string("adb_pairing_code_six_digits",
                    "The pairing code must contain exactly 6 digits"));
            return;
        }

        pairing = true;
        mainHandler.removeCallbacks(timeout);
        closeDiscovery();
        notifyService(workingNotification());
        AdbShell.onNotificationPairingState(generation, AdbShell.ConnectionState.PAIRING);

        executor.execute(() -> {
            try {
                wirelessAdb.pair(endpoint, normalized);
                // Pairing itself has completed at this point. The following TCP setup can
                // take several seconds (mDNS discovery has a 20-second timeout), so do not
                // leave the inline-reply notification saying that the code is still being
                // verified while that separate step is running.
                mainHandler.post(this::showFinishingConnection);
                wirelessAdb.enableTcpAfterPairing(null);
                mainHandler.post(() -> {
                    AdbShell.onNotificationPairingSuccess(generation);
                    finishWithResult(
                            string("adb_connected_title", "ADB connected"),
                            string("adb_pairing_success",
                                    "Successfully paired with the six-digit code"));
                });
            } catch (AdbInvalidPairingCodeException invalidCode) {
                mainHandler.post(() -> {
                    pairing = false;
                    mainHandler.postDelayed(timeout, TIMEOUT_MS);
                    showCodePrompt(endpoint, string("adb_pairing_code_invalid",
                            "Incorrect pairing code. Try again"));
                    AdbShell.onNotificationPairingState(
                            generation, AdbShell.ConnectionState.WAITING_FOR_PAIRING_CODE);
                });
            } catch (Throwable error) {
                mainHandler.post(() -> fail(error));
            }
        });
    }

    private void showCodePrompt(AdbService endpoint, String detail) {
        notifyService(codeInputNotification(endpoint, detail));
    }

    private Notification codeInputNotification(AdbService endpoint, String detail) {
        RemoteInput input = new RemoteInput.Builder(REMOTE_INPUT_CODE)
                .setLabel(string("adb_enter_pairing_code_label",
                        "Enter the six-digit pairing code"))
                .build();
        Intent reply = new Intent(this, AdbPairingService.class)
                .setAction(ACTION_REPLY)
                .putExtra(EXTRA_GENERATION, generation)
                .putExtra(EXTRA_KEY_NAME, keyName)
                .putExtra(EXTRA_HOST, endpoint.host)
                .putExtra(EXTRA_PORT, endpoint.port);
        PendingIntent replyIntent = PendingIntent.getService(
                this,
                2,
                reply,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE);
        Notification.Action action = new Notification.Action.Builder(
                null, string("adb_enter_code", "Enter code"), replyIntent)
                .addRemoteInput(input)
                .build();

        return baseNotification(string("adb_pairing_notification_title",
                        "Enter ADB pairing code"), CODE_CHANNEL)
                .setContentText(detail)
                .setStyle(new Notification.BigTextStyle().bigText(
                        string("adb_pairing_notification_instruction",
                                "%1$s\nOpen this notification and enter the code shown in "
                                        + "Wireless debugging.", detail)))
                .setOngoing(true)
                .setOnlyAlertOnce(false)
                .setPriority(Notification.PRIORITY_MAX)
                .setCategory(Notification.CATEGORY_MESSAGE)
                .addAction(action)
                .addAction(stopAction())
                .build();
    }

    private Notification searchingNotification() {
        return baseNotification(string("adb_searching_title",
                        "Searching for ADB pairing service"), CODE_CHANNEL)
                .setContentText(string("adb_searching_text",
                        "Open Pair device with pairing code in Wireless debugging"))
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .addAction(stopAction())
                .build();
    }

    private Notification workingNotification() {
        return baseNotification(string("adb_pairing_working_title",
                        "Pairing ADB"), CODE_CHANNEL)
                .setContentText(string("adb_pairing_working_text",
                        "Verifying the six-digit code…"))
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_PROGRESS)
                .build();
    }

    private void showFinishingConnection() {
        notifyService(finishingConnectionNotification());
    }

    private Notification finishingConnectionNotification() {
        return baseNotification(string("adb_paired_title", "ADB paired"), CODE_CHANNEL)
                .setContentText(string("adb_finishing_connection",
                        "Finishing the connection…"))
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_PROGRESS)
                .build();
    }

    private Notification.Action stopAction() {
        Intent stop = new Intent(this, AdbPairingService.class)
                .setAction(ACTION_STOP)
                .putExtra(EXTRA_GENERATION, generation)
                .putExtra(EXTRA_KEY_NAME, keyName);
        PendingIntent pending = PendingIntent.getService(
                this,
                3,
                stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Action.Builder(
                null, string("adb_cancel", "Cancel"), pending).build();
    }

    private Notification.Builder baseNotification(String title, String channel) {
        Notification.Builder builder = new Notification.Builder(this, channel)
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentTitle(title)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setShowWhen(true);
        Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (launch != null) {
            builder.setContentIntent(PendingIntent.getActivity(
                    this,
                    1,
                    launch,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        }
        return builder;
    }

    private void createNotificationChannels() {
        NotificationChannel code = new NotificationChannel(
                CODE_CHANNEL,
                string("adb_pairing_channel_name", "ADB pairing"),
                NotificationManager.IMPORTANCE_HIGH);
        code.enableVibration(true);
        code.setShowBadge(true);

        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.createNotificationChannel(code);
        manager.cancel(LEGACY_CODE_NOTIFICATION_ID);
        manager.deleteNotificationChannel("dnturbo_adb_pairing_code");
        // Remove the old foreground-service channel left by versions that displayed
        // a second notification during pairing.
        manager.deleteNotificationChannel("dnturbo_adb_pairing_service");
    }

    private void notifyService(Notification notification) {
        getSystemService(NotificationManager.class).notify(SERVICE_NOTIFICATION_ID, notification);
    }

    private void fail(Throwable error) {
        AdbShell.onNotificationPairingError(
                generation, AdbShell.ConnectionError.CONNECTION_FAILED, error);
        finishWithResult(
                string("adb_connection_failed_title", "Unable to connect ADB"),
                friendlyMessage(error));
    }

    private void finishWithResult(String title, String detail) {
        mainHandler.removeCallbacks(timeout);
        closeDiscovery();
        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.cancel(SERVICE_NOTIFICATION_ID);
        Notification result = baseNotification(title, CODE_CHANNEL)
                .setContentText(detail)
                .setStyle(new Notification.BigTextStyle().bigText(detail))
                .setAutoCancel(true)
                .setOngoing(false)
                .setPriority(Notification.PRIORITY_HIGH)
                .build();
        manager.notify(RESULT_NOTIFICATION_ID, result);
        stopSelf();
    }

    private void stopPairing() {
        mainHandler.removeCallbacks(timeout);
        closeDiscovery();
        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.cancel(SERVICE_NOTIFICATION_ID);
        stopSelf();
    }

    private void closeDiscovery() {
        Closeable current = discovery;
        discovery = null;
        if (current != null) {
            try {
                current.close();
            } catch (Exception ignored) {
            }
        }
    }

    private static String friendlyMessage(Throwable error) {
        Throwable current = error;
        while (current.getCause() != null && current.getCause() != current) {
            current = current.getCause();
        }
        String message = current.getMessage();
        return message == null || message.trim().isEmpty()
                ? current.getClass().getSimpleName() : message;
    }

    private String string(String name, String english, Object... arguments) {
        return AdbStrings.get(this, name, english, arguments);
    }
}
