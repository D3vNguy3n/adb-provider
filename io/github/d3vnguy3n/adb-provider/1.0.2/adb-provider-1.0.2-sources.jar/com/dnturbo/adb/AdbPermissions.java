package com.dnturbo.adb;

import android.Manifest;
import android.os.Build;

public final class AdbPermissions {

    private AdbPermissions() {
    }

    /**
     * Runtime permission required for mDNS discovery / pairing on Android 16+.
     * Null on older versions (install-time INTERNET is enough).
     */
    public static String localNetworkPermission() {
        if (Build.VERSION.SDK_INT >= 37) {
            return "android.permission.ACCESS_LOCAL_NETWORK";
        }
        if (Build.VERSION.SDK_INT >= 36) {
            return Manifest.permission.NEARBY_WIFI_DEVICES;
        }
        return null;
    }
}
