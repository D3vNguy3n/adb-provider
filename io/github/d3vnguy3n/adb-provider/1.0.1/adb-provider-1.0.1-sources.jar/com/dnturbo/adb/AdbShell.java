package com.dnturbo.adb;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.service.quicksettings.TileService;
import android.view.View;
import android.view.ViewTreeObserver;

import java.io.Closeable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Application-level facade for using ADB from an Activity, Service, ViewModel,
 * BroadcastReceiver, or any other Java class.
 *
 * <p>Initialize once from {@code Application.onCreate()}, then obtain the same
 * instance with {@link #get()} anywhere in the process. All blocking ADB work
 * runs on a private worker thread and callbacks are delivered on the main thread.
 */
public final class AdbShell implements Closeable {

    private static final long PAIRING_DISCOVERY_TIMEOUT_MS = 120_000L;
    private static final int RSA_CONNECT_TIMEOUT_MS = 15_000;
    private static final String PERMISSION_PREFS = "com.dnturbo.adb.permission_state";
    private static final String NOTIFICATION_DENIALS = "notification_denials";

    public interface Callback<T> {
        void onSuccess(T value);

        void onError(Throwable error);
    }

    public enum ConnectionState {
        CHECKING_SETTINGS,
        TRYING_RSA,
        REQUESTING_NOTIFICATION_PERMISSION,
        REQUESTING_LOCAL_NETWORK_PERMISSION,
        WAITING_FOR_PAIRING_CODE,
        PAIRING,
        CONNECTED
    }

    public enum ConnectionMode {
        RSA,
        PAIRING_CODE
    }

    public enum ConnectionError {
        ACTIVITY_UNAVAILABLE,
        DEVELOPER_OPTIONS_DISABLED,
        USB_DEBUGGING_DISABLED,
        NOTIFICATION_PERMISSION_DENIED,
        LOCAL_NETWORK_PERMISSION_DENIED,
        USER_CANCELLED,
        CONNECTION_FAILED
    }

    /** Detailed callback for the automatic RSA -> pairing-code connection flow. */
    public interface ConnectionCallback {
        default void onStateChanged(ConnectionState state) {
        }

        void onConnected(ConnectionMode mode);

        void onError(ConnectionError error, Throwable cause);
    }

    private static volatile AdbShell instance;

    private final WirelessAdb wirelessAdb;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Context appContext;
    private final String keyName;
    private final AtomicInteger connectionGeneration = new AtomicInteger();
    private volatile boolean lastConnectionSucceeded;
    private volatile AdbClient pendingRsaClient;
    private ConnectionCallback notificationPairingCallback;
    private int notificationPairingGeneration = -1;
    private RsaFocusWatcher rsaFocusWatcher;

    private AdbShell(Context context, String keyName) {
        appContext = context.getApplicationContext();
        this.keyName = keyName;
        wirelessAdb = WirelessAdb.create(appContext, keyName);
    }

    public static AdbShell initialize(Context context) {
        return initialize(context, "AdbShellTest");
    }

    public static AdbShell initialize(Context context, String keyName) {
        if (context == null) {
            throw new IllegalArgumentException("context == null");
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            throw new UnsupportedOperationException("Wireless ADB requires Android 11 or newer");
        }
        AdbShell current = instance;
        if (current == null) {
            synchronized (AdbShell.class) {
                current = instance;
                if (current == null) {
                    current = new AdbShell(context, keyName);
                    instance = current;
                }
            }
        }
        return current;
    }

    public static AdbShell get() {
        AdbShell current = instance;
        if (current == null) {
            throw new IllegalStateException(
                    "Call AdbShell.initialize(applicationContext) first");
        }
        return current;
    }

    /** Returns Android's current USB-debugging setting. */
    public boolean isUsbDebuggingEnabled() {
        return Settings.Global.getInt(
                appContext.getContentResolver(), Settings.Global.ADB_ENABLED, 0) == 1;
    }

    /** Returns the last observed result, not a permanent guarantee of connectivity. */
    public boolean wasConnected() {
        return lastConnectionSucceeded;
    }

    /**
     * Complete one-tap connection flow for a button or other UI action.
     *
     * <p>It first tries the active local ADB port with the saved RSA key. If that
     * is unavailable, it opens Wireless debugging and posts a notification where
     * the six-digit pairing code can be entered, like Shizuku's pairing flow.
     */
    public void connect(Activity activity, Callback<Void> callback) {
        requireCallback(callback);
        connect(activity, new ConnectionCallback() {
            @Override
            public void onConnected(ConnectionMode mode) {
                callback.onSuccess(null);
            }

            @Override
            public void onError(ConnectionError error, Throwable cause) {
                callback.onError(cause);
            }
        });
    }

    /** Same automatic flow as {@link #connect(Activity, Callback)}, with typed states/errors. */
    public void connect(Activity activity, ConnectionCallback callback) {
        if (activity == null) {
            throw new IllegalArgumentException("activity == null");
        }
        requireConnectionCallback(callback);
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(() -> connect(activity, callback));
            return;
        }

        int generation = connectionGeneration.incrementAndGet();
        closePendingRsaClient();
        removeRsaFocusWatcher();
        cancelNotificationPairing();
        lastConnectionSucceeded = false;
        notifyStateChanged(callback, ConnectionState.CHECKING_SETTINGS);

        if (!isActivityUsable(activity)) {
            finishError(callback, generation, ConnectionError.ACTIVITY_UNAVAILABLE,
                    new AdbException(string("adb_activity_unavailable", "Activity is unavailable")));
            return;
        }
        if (!isDeveloperOptionsEnabled()) {
            showSettingRequired(
                    activity,
                    string("adb_dev_options_title", "Enable Developer options"),
                    string("adb_dev_options_message",
                            "Enable Developer options, then tap Connect again."),
                    string("adb_open_phone_info", "Open phone information"),
                    () -> openSettings(activity, Settings.ACTION_DEVICE_INFO_SETTINGS),
                    callback,
                    generation,
                    ConnectionError.DEVELOPER_OPTIONS_DISABLED
            );
            return;
        }
        if (!isUsbDebuggingEnabled()) {
            showSettingRequired(
                    activity,
                    string("adb_usb_debugging_title", "Enable USB debugging"),
                    string("adb_usb_debugging_message",
                            "Enable USB debugging in Developer options, then tap Connect again."),
                    string("adb_open_developer_options", "Open Developer options"),
                    () -> openUsbDebuggingSettings(activity),
                    callback,
                    generation,
                    ConnectionError.USB_DEBUGGING_DISABLED
            );
            return;
        }

        notifyStateChanged(callback, ConnectionState.TRYING_RSA);
        RsaFocusWatcher watcher = installRsaFocusWatcher(activity, generation);
        executor.execute(() -> tryRsaThenPair(activity, callback, generation, watcher));
    }

    /** Connects with the saved ADB key. Use this after the device has been paired once. */
    public void connect(Callback<Void> callback) {
        execute(callback, () -> {
            try (AdbClient ignored = wirelessAdb.connectForUse(null)) {
                lastConnectionSucceeded = true;
                return null;
            } catch (Throwable error) {
                lastConnectionSucceeded = false;
                throw error;
            }
        });
    }

    /**
     * First-time connection. Open Android's "Pair device with pairing code" dialog,
     * then pass its six-digit code here. The pairing endpoint is discovered automatically.
     */
    public void connect(String pairingCode, Callback<Void> callback) {
        if (pairingCode == null || !pairingCode.trim().matches("\\d{6}")) {
            postError(callback, new AdbInvalidPairingCodeException());
            return;
        }
        execute(callback, () -> {
            try {
                AdbService endpoint = wirelessAdb.waitForPairingService(
                        PAIRING_DISCOVERY_TIMEOUT_MS);
                wirelessAdb.pair(endpoint, pairingCode.trim());
                wirelessAdb.enableTcpAfterPairing(null);
                lastConnectionSucceeded = true;
                return null;
            } catch (Throwable error) {
                lastConnectionSucceeded = false;
                throw error;
            }
        });
    }

    /** Runs a shell command after establishing a fresh, real connection. */
    public void run(String command, Callback<String> callback) {
        if (command == null || command.trim().isEmpty()) {
            postError(callback, new IllegalArgumentException("command is empty"));
            return;
        }
        execute(callback, () -> {
            try (AdbClient client = wirelessAdb.connectForUse(null)) {
                String output = client.shell(command);
                lastConnectionSucceeded = true;
                return output;
            } catch (Throwable error) {
                lastConnectionSucceeded = false;
                throw error;
            }
        });
    }

    @Override
    public void close() {
        connectionGeneration.incrementAndGet();
        lastConnectionSucceeded = false;
        closePendingRsaClient();
        cancelNotificationPairing();
        executor.shutdownNow();
        mainHandler.removeCallbacksAndMessages(null);
        if (Looper.myLooper() == Looper.getMainLooper()) {
            removeRsaFocusWatcher();
        } else {
            mainHandler.post(this::removeRsaFocusWatcher);
        }
        synchronized (AdbShell.class) {
            if (instance == this) {
                instance = null;
            }
        }
    }

    private <T> void execute(Callback<T> callback, Task<T> task) {
        requireCallback(callback);
        executor.execute(() -> {
            try {
                T result = task.run();
                mainHandler.post(() -> callback.onSuccess(result));
            } catch (Throwable error) {
                mainHandler.post(() -> callback.onError(error));
            }
        });
    }

    private <T> void postError(Callback<T> callback, Throwable error) {
        requireCallback(callback);
        mainHandler.post(() -> callback.onError(error));
    }

    private void tryRsaThenPair(
            Activity activity,
            ConnectionCallback callback,
            int generation,
            RsaFocusWatcher watcher) {
        int activePort = wirelessAdb.getActiveTcpPort();
        int directPort = activePort > 0 ? activePort : WirelessAdb.DEFAULT_TCP_PORT;
        AdbClient candidate = null;
        try {
            if (!isCurrent(generation)) {
                return;
            }
            candidate = new AdbClient(
                    WirelessAdb.LOOPBACK,
                    directPort,
                    wirelessAdb.getKey(),
                    RSA_CONNECT_TIMEOUT_MS
            );
            pendingRsaClient = candidate;
            candidate.connect();
            if (!isCurrent(generation)) {
                return;
            }
            mainHandler.post(() -> {
                removeRsaFocusWatcher(watcher);
                if (isCurrent(generation)) {
                    finishSuccess(callback, generation, ConnectionMode.RSA);
                }
            });
        } catch (Throwable rsaError) {
            if (isCurrent(generation)) {
                mainHandler.post(() -> {
                    removeRsaFocusWatcher(watcher);
                    beginPairingFallback(activity, callback, generation);
                });
            }
        } finally {
            if (candidate != null) {
                candidate.close();
            }
            if (pendingRsaClient == candidate) {
                pendingRsaClient = null;
            }
        }
    }

    private void beginPairingFallback(
            Activity activity, ConnectionCallback callback, int generation) {
        if (!isCurrent(generation)) {
            return;
        }
        if (!isActivityUsable(activity)) {
            finishError(callback, generation, ConnectionError.ACTIVITY_UNAVAILABLE,
                    new AdbException(string("adb_activity_unavailable", "Activity is unavailable")));
            return;
        }
        if (!isDeveloperOptionsEnabled() || !isUsbDebuggingEnabled()) {
            ConnectionError error = !isDeveloperOptionsEnabled()
                    ? ConnectionError.DEVELOPER_OPTIONS_DISABLED
                    : ConnectionError.USB_DEBUGGING_DISABLED;
            finishError(callback, generation, error, new AdbException(
                    string("adb_developer_settings_required",
                            "Developer options and USB debugging must be enabled")));
            return;
        }

        String permission = missingPairingPermission(activity);
        if (permission != null
                && activity.checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
            boolean notificationPermission = Manifest.permission.POST_NOTIFICATIONS.equals(permission);
            if (notificationPermission && notificationDenialCount() >= 2) {
                showNotificationPermissionSettingsRequired(activity, callback, generation);
                return;
            }
            notifyStateChanged(callback, notificationPermission
                    ? ConnectionState.REQUESTING_NOTIFICATION_PERMISSION
                    : ConnectionState.REQUESTING_LOCAL_NETWORK_PERMISSION);
            AdbPermissionFragment.request(activity, permission, granted -> {
                if (!isCurrent(generation)) {
                    return;
                }
                if (granted) {
                    if (notificationPermission) {
                        clearNotificationDenials();
                    }
                    beginPairingFallback(activity, callback, generation);
                } else {
                    if (notificationPermission && recordNotificationDenial() >= 2) {
                        showNotificationPermissionSettingsRequired(
                                activity, callback, generation);
                    } else {
                        finishError(callback, generation,
                                notificationPermission
                                        ? ConnectionError.NOTIFICATION_PERMISSION_DENIED
                                        : ConnectionError.LOCAL_NETWORK_PERMISSION_DENIED,
                                new SecurityException(notificationPermission
                                        ? string("adb_notification_permission_denied",
                                                "Notification permission was denied")
                                        : string("adb_local_network_permission_denied",
                                                "Local network permission was denied")));
                    }
                }
            });
            return;
        }
        startNotificationPairing(activity, callback, generation);
    }

    private int notificationDenialCount() {
        return appContext.getSharedPreferences(PERMISSION_PREFS, Context.MODE_PRIVATE)
                .getInt(NOTIFICATION_DENIALS, 0);
    }

    private int recordNotificationDenial() {
        int denials = notificationDenialCount() + 1;
        appContext.getSharedPreferences(PERMISSION_PREFS, Context.MODE_PRIVATE)
                .edit()
                .putInt(NOTIFICATION_DENIALS, denials)
                .apply();
        return denials;
    }

    private void clearNotificationDenials() {
        appContext.getSharedPreferences(PERMISSION_PREFS, Context.MODE_PRIVATE)
                .edit()
                .remove(NOTIFICATION_DENIALS)
                .apply();
    }

    private void showNotificationPermissionSettingsRequired(
            Activity activity, ConnectionCallback callback, int generation) {
        showSettingRequired(
                activity,
                string("adb_notification_permission_title", "Enable notification permission"),
                string("adb_notification_permission_message",
                        "Notification permission was denied multiple times, so Android cannot "
                                + "show the permission prompt again. Open settings, enable "
                                + "notifications for this app, then tap Connect again."),
                string("adb_open_notification_settings", "Open notification settings"),
                () -> openAppNotificationSettings(activity),
                callback,
                generation,
                ConnectionError.NOTIFICATION_PERMISSION_DENIED
        );
    }

    private void openAppNotificationSettings(Activity activity) {
        try {
            activity.startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, activity.getPackageName()));
        } catch (Throwable ignored) {
            try {
                activity.startActivity(new Intent(
                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + activity.getPackageName())));
            } catch (Throwable ignoredAgain) {
                openSettings(activity, Settings.ACTION_SETTINGS);
            }
        }
    }

    private void startNotificationPairing(
            Activity activity, ConnectionCallback callback, int generation) {
        if (!isCurrent(generation)) {
            return;
        }
        if (!isActivityUsable(activity)) {
            finishError(callback, generation, ConnectionError.ACTIVITY_UNAVAILABLE,
                    new AdbException(string("adb_activity_unavailable", "Activity is unavailable")));
            return;
        }
        notificationPairingCallback = callback;
        notificationPairingGeneration = generation;
        notifyStateChanged(callback, ConnectionState.WAITING_FOR_PAIRING_CODE);
        try {
            AdbPairingService.start(appContext, generation, keyName);
            openWirelessDebuggingSettings(activity);
        } catch (Throwable error) {
            finishError(callback, generation, ConnectionError.CONNECTION_FAILED, error);
        }
    }

    private void showSettingRequired(
            Activity activity,
            String title,
            String message,
            String positiveText,
            Runnable openAction,
            ConnectionCallback callback,
            int generation,
            ConnectionError error) {
        new AlertDialog.Builder(activity)
                .setTitle(title)
                .setMessage(message)
                .setNegativeButton(string("adb_cancel", "Cancel"), null)
                .setPositiveButton(positiveText, (ignored, which) -> openAction.run())
                .show();
        finishError(callback, generation, error, new AdbException(message));
    }

    private void openWirelessDebuggingSettings(Activity activity) {
        Intent wireless = new Intent(TileService.ACTION_QS_TILE_PREFERENCES)
                .setPackage("com.android.settings")
                .putExtra(Intent.EXTRA_COMPONENT_NAME, new ComponentName(
                        "com.android.settings",
                        "com.android.settings.development.qstile.DevelopmentTiles$WirelessDebugging"));
        try {
            activity.startActivity(wireless);
        } catch (Throwable ignored) {
            openWirelessDebuggingDeveloperOptions(activity);
        }
    }

    private void openUsbDebuggingSettings(Activity activity) {
        openDeveloperOption(activity, "enable_adb");
    }

    private void openWirelessDebuggingDeveloperOptions(Activity activity) {
        openDeveloperOption(activity, "toggle_adb_wireless");
    }

    private void openDeveloperOption(Activity activity, String preferenceKey) {
        try {
            activity.startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
                    .putExtra(":settings:fragment_args_key", preferenceKey));
        } catch (Throwable ignored) {
            openSettings(activity, Settings.ACTION_SETTINGS);
        }
    }

    private void openSettings(Activity activity, String action) {
        try {
            activity.startActivity(new Intent(action));
        } catch (Throwable ignored) {
            try {
                activity.startActivity(new Intent(Settings.ACTION_SETTINGS));
            } catch (Throwable ignoredAgain) {
            }
        }
    }

    private boolean isDeveloperOptionsEnabled() {
        return Settings.Global.getInt(appContext.getContentResolver(),
                Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1;
    }

    private String string(String name, String english, Object... arguments) {
        return AdbStrings.get(appContext, name, english, arguments);
    }

    private String missingPairingPermission(Activity activity) {
        if (Build.VERSION.SDK_INT >= 33
                && activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            return Manifest.permission.POST_NOTIFICATIONS;
        }
        String localNetwork = AdbPermissions.localNetworkPermission();
        if (localNetwork != null
                && activity.checkSelfPermission(localNetwork)
                != PackageManager.PERMISSION_GRANTED) {
            return localNetwork;
        }
        return null;
    }

    private boolean isCurrent(int generation) {
        return generation == connectionGeneration.get();
    }

    private void finishSuccess(
            ConnectionCallback callback, int generation, ConnectionMode mode) {
        if (!connectionGeneration.compareAndSet(generation, generation + 1)) {
            return;
        }
        lastConnectionSucceeded = true;
        clearNotificationPairing(generation);
        notifyStateChanged(callback, ConnectionState.CONNECTED);
        callback.onConnected(mode);
    }

    private static void notifyStateChanged(
            ConnectionCallback callback, ConnectionState state) {
        try {
            callback.onStateChanged(state);
        } catch (AbstractMethodError ignored) {
            // Some older Android builders do not desugar default interface methods.
        }
    }

    private void finishError(
            ConnectionCallback callback,
            int generation,
            ConnectionError connectionError,
            Throwable cause) {
        if (!connectionGeneration.compareAndSet(generation, generation + 1)) {
            return;
        }
        lastConnectionSucceeded = false;
        closePendingRsaClient();
        clearNotificationPairing(generation);
        callback.onError(connectionError, cause);
    }

    private void closePendingRsaClient() {
        AdbClient client = pendingRsaClient;
        pendingRsaClient = null;
        if (client != null) {
            client.close();
        }
    }

    private void cancelNotificationPairing() {
        if (notificationPairingCallback == null) {
            return;
        }
        notificationPairingCallback = null;
        notificationPairingGeneration = -1;
        try {
            AdbPairingService.stop(appContext);
        } catch (Throwable ignored) {
        }
    }

    private void clearNotificationPairing(int generation) {
        if (notificationPairingGeneration == generation) {
            notificationPairingCallback = null;
            notificationPairingGeneration = -1;
        }
    }

    private RsaFocusWatcher installRsaFocusWatcher(Activity activity, int generation) {
        removeRsaFocusWatcher();
        View view = activity.getWindow().getDecorView();
        AtomicBoolean obscured = new AtomicBoolean(false);
        ViewTreeObserver.OnWindowFocusChangeListener listener = hasFocus -> {
            if (!isCurrent(generation)) {
                return;
            }
            if (!hasFocus) {
                obscured.set(true);
                return;
            }
            if (obscured.compareAndSet(true, false)) {
                mainHandler.postDelayed(() -> {
                    if (isCurrent(generation)) {
                        closePendingRsaClient();
                    }
                }, 1_000L);
            }
        };
        RsaFocusWatcher watcher = new RsaFocusWatcher(view, listener);
        rsaFocusWatcher = watcher;
        view.getViewTreeObserver().addOnWindowFocusChangeListener(listener);
        return watcher;
    }

    private void removeRsaFocusWatcher() {
        removeRsaFocusWatcher(rsaFocusWatcher);
    }

    private void removeRsaFocusWatcher(RsaFocusWatcher watcher) {
        if (watcher == null) {
            return;
        }
        ViewTreeObserver observer = watcher.view.getViewTreeObserver();
        if (observer.isAlive()) {
            observer.removeOnWindowFocusChangeListener(watcher.listener);
        }
        if (rsaFocusWatcher == watcher) {
            rsaFocusWatcher = null;
        }
    }

    static void onNotificationPairingState(int generation, ConnectionState state) {
        AdbShell current = instance;
        if (current == null) {
            return;
        }
        current.mainHandler.post(() -> {
            if (current.isCurrent(generation)
                    && current.notificationPairingGeneration == generation
                    && current.notificationPairingCallback != null) {
                notifyStateChanged(current.notificationPairingCallback, state);
            }
        });
    }

    static void onNotificationPairingSuccess(int generation) {
        AdbShell current = instance;
        if (current == null) {
            return;
        }
        current.mainHandler.post(() -> {
            ConnectionCallback callback = current.notificationPairingGeneration == generation
                    ? current.notificationPairingCallback : null;
            if (callback != null) {
                current.finishSuccess(callback, generation, ConnectionMode.PAIRING_CODE);
            }
        });
    }

    static void onNotificationPairingError(
            int generation, ConnectionError error, Throwable cause) {
        AdbShell current = instance;
        if (current == null) {
            return;
        }
        current.mainHandler.post(() -> {
            ConnectionCallback callback = current.notificationPairingGeneration == generation
                    ? current.notificationPairingCallback : null;
            if (callback != null) {
                current.finishError(callback, generation, error, cause);
            }
        });
    }

    private static boolean isActivityUsable(Activity activity) {
        return !activity.isFinishing()
                && (Build.VERSION.SDK_INT < 17 || !activity.isDestroyed());
    }

    private static <T> void requireCallback(Callback<T> callback) {
        if (callback == null) {
            throw new IllegalArgumentException("callback == null");
        }
    }

    private static void requireConnectionCallback(ConnectionCallback callback) {
        if (callback == null) {
            throw new IllegalArgumentException("callback == null");
        }
    }

    private static final class RsaFocusWatcher {
        final View view;
        final ViewTreeObserver.OnWindowFocusChangeListener listener;

        RsaFocusWatcher(View view, ViewTreeObserver.OnWindowFocusChangeListener listener) {
            this.view = view;
            this.listener = listener;
        }
    }

    private interface Task<T> {
        T run() throws Throwable;
    }
}
